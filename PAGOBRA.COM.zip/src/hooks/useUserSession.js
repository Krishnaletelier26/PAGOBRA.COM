
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from "@/components/ui/use-toast";

// Mock proposal data - moved here for hook usage
const mockProposal = {
  id: 'prop123',
  builderName: 'Constructora XYZ',
  projectName: 'Modelo OT-123',
  basePrice: 8200000,
  additionals: [
    { name: 'Fosa Séptica', price: 550000 },
    { name: 'Empalme de Luz', price: 300000 },
  ],
  get totalPrice() {
    return this.basePrice + this.additionals.reduce((sum, item) => sum + item.price, 0);
  },
  status: 'pending' // 'pending', 'accepted', 'rejected'
};

function useUserSession() {
  const [userType, setUserType] = useState(null);
  const [hasNotification, setHasNotification] = useState(false);
  const [notificationData, setNotificationData] = useState(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    let isMounted = true;
    let timer;

    const checkUser = () => {
      try {
        const storedUserType = localStorage.getItem('userType');
        if (storedUserType && ['propietario', 'constructora'].includes(storedUserType)) {
          if (isMounted) setUserType(storedUserType);
          console.log("User type loaded:", storedUserType);

          // Simulate receiving a notification
          timer = setTimeout(() => {
            if (isMounted) {
              if (storedUserType === 'propietario') {
                if (mockProposal.status === 'pending') {
                  setNotificationData(mockProposal);
                  setHasNotification(true);
                  console.log(`Simulated proposal notification received for ${storedUserType}`);
                } else {
                  console.log(`Proposal ${mockProposal.id} already actioned (${mockProposal.status}). No new notification.`);
                  // Optionally set a different notification or none
                  setHasNotification(false);
                }
              } else { // constructora
                // Simulate acceptance notification for constructor
                setNotificationData({ type: 'acceptance', clientName: 'Carlos Silva', projectName: 'Modelo Austral' });
                setHasNotification(true);
                console.log(`Simulated acceptance notification received for ${storedUserType}`);
              }
            }
          }, 3000); // 3-second delay

        } else {
          if (isMounted) {
            toast({
              title: "Sesión no iniciada",
              description: "Por favor, inicia sesión para continuar.",
              variant: "destructive",
            });
            navigate('/login');
          }
        }
      } catch (error) {
        console.error("Error reading userType from localStorage:", error);
        if (isMounted) {
          toast({
            title: "Error al cargar",
            description: "No se pudo determinar el tipo de usuario.",
            variant: "destructive",
          });
          navigate('/login');
        }
      }
    };

    checkUser();

    return () => {
      isMounted = false;
      if (timer) clearTimeout(timer);
    };
  }, [navigate, toast]); // Dependencies for the effect

  // Function to handle proposal actions (accept/reject)
  const handleProposalAction = (proposalId, accepted) => {
    if (mockProposal.id === proposalId) {
      mockProposal.status = accepted ? 'accepted' : 'rejected';
      // Update notification state if the action resolves the pending notification
      setNotificationData(prev => ({ ...prev, status: mockProposal.status }));
      // Decide if the notification bell should remain active
      // setHasNotification(false); // Example: clear notification once actioned
    }
    console.log(`Proposal ${proposalId} ${accepted ? 'accepted' : 'rejected'}`);
    // Note: Dialog closing is handled in HomePage now
  };

  return {
    userType,
    hasNotification,
    notificationData,
    handleProposalAction,
    // Expose mockProposal status if needed elsewhere, though maybe not directly
  };
}

export default useUserSession;
  