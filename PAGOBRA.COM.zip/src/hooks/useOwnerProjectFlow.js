
import { useState, useEffect, useCallback } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { loadFromLocalStorage, saveToLocalStorage, initializeMilestonesStatus } from '@/lib/storageUtils';
import { projectMilestonesData, findNextActionableMilestone } from '@/lib/projectUtils';
import { initialBuildersData as mockBuilders, houseModel as mockHouseModel } from '@/lib/mockData';
import useDialogManager from '@/hooks/useDialogManager'; // Import the new hook

// --- Initial State Setup ---
const initialProjectsData = []; // Start with no projects in the general list initially

// Pre-create a signed project for demonstration
const createInitialSignedProject = () => {
    const builder = mockBuilders.find(b => b.id === 'builder_2'); // Choose Edifica Beta
    if (!builder) return null;

    const houseModel = mockHouseModel; // Use the defined house model

    const newProject = {
        id: `proj_initial_${Date.now()}`,
        name: `Proyecto ${houseModel.name} - ${builder.name}`,
        client: 'Usuario Actual (Demo)',
        address: 'Dirección Demo 123',
        builderId: builder.id,
        builderName: builder.name,
        modelName: houseModel.name,
        progress: 0, // Will be updated below
        details: {
            startDate: new Date().toISOString().split('T')[0],
            estimatedEndDate: 'Pendiente',
            currentPhase: projectMilestonesData[0]?.name || 'Inicio',
            totalCost: builder.basePrice, // Use base price for simplicity, adjust if needed
        },
        milestones: initializeMilestonesStatus(),
        imageUrl: houseModel.imageUrl,
        additionals: [], // Assume no additionals for initial demo
        status: 'signed',
        review: null,
    };

    // Mark 'Acuerdo' as paid and set initial progress
    const acuerdoMilestoneData = projectMilestonesData.find(m => m.name === 'Acuerdo');
    if (newProject.milestones['Acuerdo'] && acuerdoMilestoneData) {
        newProject.milestones['Acuerdo'].paid = 1;
        newProject.progress = acuerdoMilestoneData.range[1] || 10;
        newProject.details.currentPhase = projectMilestonesData[1]?.name || 'Siguiente Fase';
    } else {
        newProject.progress = 10; // Fallback
    }

    // Save this initial project to localStorage so it persists on refresh
    saveToLocalStorage('signedProject', newProject);
    // Also add it to the general projects list in storage
    const existingProjects = loadFromLocalStorage('ownerProjects', []);
    if (!existingProjects.some(p => p.id === newProject.id)) {
       saveToLocalStorage('ownerProjects', [...existingProjects, newProject]);
    }


    return newProject;
};

// Load initial signed project or create if it doesn't exist in storage
const initialSignedProject = loadFromLocalStorage('signedProject', null) || createInitialSignedProject();

// --- Hook Logic ---
function useOwnerProjectFlow() {
    const { toast } = useToast();

    // --- State Definitions ---
    const [builders, setBuilders] = useState(() => loadFromLocalStorage('ownerBuildersData', mockBuilders));
    const [projects, setProjects] = useState(() => loadFromLocalStorage('ownerProjects', initialProjectsData));
    const [signedProject, setSignedProject] = useState(initialSignedProject); // Use the pre-configured initial state
    const [houseModel] = useState(mockHouseModel);

    // Use the dedicated dialog manager hook
    const {
        dialogState,
        openDialog,
        closeDialog,
        selectedBuilderId,
        setSelectedBuilderId,
        selectedMilestoneName,
        setSelectedMilestoneName,
        selectedMilestoneImages,
        setSelectedMilestoneImages,
        selectedMilestoneForDetail,
        setSelectedMilestoneForDetail,
    } = useDialogManager();

    // --- Computed Values ---
    const selectedBuilder = builders.find(b => b.id === selectedBuilderId);
    const milestonesStatus = signedProject?.milestones || initializeMilestonesStatus();
    const projectProgress = signedProject?.progress || 0;
    const nextPayableMilestone = signedProject ? findNextActionableMilestone(projectProgress, milestonesStatus) : null;
    const selectedMilestoneToPay = (selectedMilestoneName && nextPayableMilestone && selectedMilestoneName === nextPayableMilestone.name) ? nextPayableMilestone : null;

    // --- Effects ---
    useEffect(() => {
        saveToLocalStorage('ownerBuildersData', builders);
    }, [builders]);

    useEffect(() => {
        saveToLocalStorage('ownerProjects', projects);
    }, [projects]);

    useEffect(() => {
        // Sync with localStorage for external updates (constructor simulation)
        const checkLocalStorage = () => {
            const storedSignedProject = loadFromLocalStorage('signedProject', null);
            if (JSON.stringify(storedSignedProject) !== JSON.stringify(signedProject)) {
                setSignedProject(storedSignedProject);
                 // Also update the main projects list if the signed project changed
                 if (storedSignedProject) {
                    setProjects(prev => prev.map(p => p.id === storedSignedProject.id ? storedSignedProject : p));
                 }
            }
        };
        const intervalId = setInterval(checkLocalStorage, 2000);
        checkLocalStorage(); // Initial check

        // Save current state to localStorage
        saveToLocalStorage('signedProject', signedProject);

        return () => clearInterval(intervalId);
    }, [signedProject]);

    // --- Simulation Helpers ---
    const simulateConstructorUpdateRequest = (visitRequestId, status) => {
        const constructorRequests = loadFromLocalStorage('constructorVisitRequests', []);
        const updatedConstructorRequests = constructorRequests.map(req =>
            req.id === visitRequestId ? { ...req, status } : req
        );
        saveToLocalStorage('constructorVisitRequests', updatedConstructorRequests);
    };

    const simulateConstructorAddProject = (project) => {
        const constructorProjects = loadFromLocalStorage('constructorProjects', []);
        const updatedConstructorProjects = [...constructorProjects, project];
        saveToLocalStorage('constructorProjects', updatedConstructorProjects);
    };

     const simulateConstructorUpdatePayment = (projectId, milestoneName) => {
        const constructorProjects = loadFromLocalStorage('constructorProjects', []);
        const updatedConstructorProjects = constructorProjects.map(p => {
            if (p.id === projectId) {
                return {
                    ...p,
                    milestones: {
                        ...p.milestones,
                        [milestoneName]: { ...(p.milestones[milestoneName] || { images: [] }), paid: 1 }
                    }
                };
            }
            return p;
        });
        saveToLocalStorage('constructorProjects', updatedConstructorProjects);
    };

     const simulateConstructorSaveReview = (projectId, reviewData) => {
        const constructorProjects = loadFromLocalStorage('constructorProjects', []);
        const updatedConstructorProjects = constructorProjects.map(p =>
            p.id === projectId ? { ...p, review: reviewData } : p
        );
        saveToLocalStorage('constructorProjects', updatedConstructorProjects);
    };


    // --- Action Handlers ---
    const handleRequestVisit = useCallback(() => {
        openDialog('visitRequestOpen');
        toast({ title: "Visita Solicitada (Simulado)", description: "La constructora se pondrá en contacto." });
        // Simulate: Update builder status or add to a request list elsewhere if needed
    }, [openDialog, toast]);

    const handleViewProposal = useCallback((builderId) => {
        setSelectedBuilderId(builderId);
        openDialog('proposalViewOpen');
    }, [openDialog, setSelectedBuilderId]);

    const handleViewBuilderProfile = useCallback((builderId) => {
        setSelectedBuilderId(builderId);
        openDialog('builderProfileOpen');
    }, [openDialog, setSelectedBuilderId]);

    const handleAcceptProposal = useCallback((builderId) => {
        const builder = builders.find(b => b.id === builderId);
        if (!builder || !builder.proposalDetails) return;

        setSelectedBuilderId(builderId);
        openDialog('contractViewOpen');
        closeDialog('proposalViewOpen');
        setBuilders(prev => prev.map(b => b.id === builderId ? { ...b, status: 'proposal_accepted' } : b));
        toast({ title: "Propuesta Aceptada", description: `Has aceptado la propuesta de ${builder.name}. Revisa el contrato.` });
        simulateConstructorUpdateRequest(builder.proposalDetails.visitRequestId, 'accepted');
    }, [builders, openDialog, closeDialog, toast, setSelectedBuilderId]);

    const handleRejectProposal = useCallback((builderId) => {
        const builder = builders.find(b => b.id === builderId);
        if (!builder) return;

        setBuilders(prev => prev.map(b => b.id === builderId ? { ...b, status: 'proposal_rejected', proposalDetails: null } : b));
        closeDialog('proposalViewOpen');
        toast({ title: "Propuesta Rechazada", description: `Has rechazado la propuesta de ${builder.name}.`, variant: "destructive" });
        if (builder.proposalDetails?.visitRequestId) {
            simulateConstructorUpdateRequest(builder.proposalDetails.visitRequestId, 'rejected');
        }
    }, [builders, closeDialog, toast]);

    const handleSignContract = useCallback(() => {
        if (!selectedBuilder || !selectedBuilder.proposalDetails) return;
        const proposal = selectedBuilder.proposalDetails;

        const newProject = {
            id: `proj_${Date.now()}`,
            name: `Proyecto ${houseModel.name} - ${selectedBuilder.name}`,
            client: 'Usuario Actual',
            address: 'Dirección Usuario',
            builderId: selectedBuilder.id,
            builderName: selectedBuilder.name,
            modelName: houseModel.name,
            progress: 0,
            details: {
                startDate: new Date().toISOString().split('T')[0],
                estimatedEndDate: 'Pendiente',
                currentPhase: projectMilestonesData[0]?.name || 'Inicio',
                totalCost: proposal.totalPrice,
            },
            milestones: initializeMilestonesStatus(),
            imageUrl: houseModel.imageUrl,
            additionals: proposal.selectedAdditionals,
            status: 'signed',
            review: null,
        };

        const acuerdoMilestoneData = projectMilestonesData.find(m => m.name === 'Acuerdo');
        if (newProject.milestones['Acuerdo'] && acuerdoMilestoneData) {
            newProject.milestones['Acuerdo'].paid = 1;
            newProject.progress = acuerdoMilestoneData.range[1] || 10;
            newProject.details.currentPhase = projectMilestonesData[1]?.name || 'Siguiente Fase';
        } else {
            newProject.progress = 10;
        }

        setSignedProject(newProject);
        setProjects(prev => [...prev, newProject]);
        setBuilders(prev => prev.map(b => b.id === selectedBuilder.id ? { ...b, status: 'contract_signed' } : b));
        closeDialog('contractViewOpen');
        toast({ title: "Contrato Firmado", description: `¡Has iniciado tu proyecto con ${selectedBuilder.name}!` });
        simulateConstructorAddProject(newProject);
    }, [selectedBuilder, houseModel, closeDialog, toast]);

    const handleMilestoneClick = useCallback((milestoneName) => {
        setSelectedMilestoneName(milestoneName);
        const status = milestonesStatus[milestoneName];
        const milestoneData = projectMilestonesData.find(m => m.name === milestoneName);
        if (!milestoneData) return;

        if (nextPayableMilestone && milestoneName === nextPayableMilestone.name) {
            const previousMilestoneIndex = projectMilestonesData.findIndex(m => m.name === milestoneName) - 1;
            let isPreviousComplete = previousMilestoneIndex < 0 || projectProgress >= projectMilestonesData[previousMilestoneIndex].range[1];

            if (isPreviousComplete) {
                openDialog('paymentOpen');
            } else {
                const prevMilestoneName = previousMilestoneIndex >= 0 ? projectMilestonesData[previousMilestoneIndex].name : "el inicio";
                toast({ title: "Hito Anterior Incompleto", description: `Espera a que "${prevMilestoneName}" esté completado (Progreso actual: ${projectProgress}%).`, variant: "default" });
            }
        } else if (status?.images && status.images.length > 0) {
            setSelectedMilestoneImages(status.images);
            openDialog('photoViewOpen');
        } else if (status?.paid) {
            toast({ title: "Esperando Fotos", description: `El constructor aún no sube fotos para "${milestoneName}".`, variant: "default" });
        } else {
            toast({ title: "Hito Pendiente", description: `"${milestoneName}" aún no está listo para pago o visualización.`, variant: "default" });
        }
    }, [milestonesStatus, nextPayableMilestone, projectProgress, openDialog, toast, setSelectedMilestoneName, setSelectedMilestoneImages]);

    const handlePayMilestone = useCallback(() => {
        if (!signedProject || !selectedMilestoneToPay) return;
        const milestoneName = selectedMilestoneToPay.name;

        const updatedMilestones = {
            ...signedProject.milestones,
            [milestoneName]: { ...(signedProject.milestones[milestoneName] || { images: [] }), paid: 1 }
        };
        const updatedProject = { ...signedProject, milestones: updatedMilestones };

        setSignedProject(updatedProject);
        // No need to update projects list here, useEffect handles sync via signedProject
        closeDialog('paymentOpen');
        setSelectedMilestoneName(null);
        toast({ title: "Pago Realizado", description: `Has pagado por el hito: ${milestoneName}.` });
        simulateConstructorUpdatePayment(signedProject.id, milestoneName);
    }, [signedProject, selectedMilestoneToPay, closeDialog, toast, setSelectedMilestoneName]);

    const handleOpenReviewPopover = useCallback(() => {
        openDialog('reviewPopoverOpen');
    }, [openDialog]);

    const handleSaveReview = useCallback((rating, text) => {
        if (!signedProject) return;
        const reviewData = { rating, text };
        const updatedProject = { ...signedProject, review: reviewData };

        setSignedProject(updatedProject);
        setProjects(prev => prev.map(p => p.id === signedProject.id ? updatedProject : p)); // Update in main list too
        closeDialog('reviewPopoverOpen');
        toast({ title: "Reseña Guardada", description: "Gracias por tus comentarios." });
        simulateConstructorSaveReview(signedProject.id, reviewData);
    }, [signedProject, closeDialog, toast]);

    const handleOpenDetailPopover = useCallback((milestoneName) => {
        setSelectedMilestoneForDetail(milestoneName);
        openDialog('milestoneDetailPopoverOpen');
    }, [openDialog, setSelectedMilestoneForDetail]);

    const handleCloseDetailPopover = useCallback(() => {
        closeDialog('milestoneDetailPopoverOpen');
        setSelectedMilestoneForDetail(null);
    }, [closeDialog, setSelectedMilestoneForDetail]);

    return {
        builders, projects, signedProject, houseModel, dialogState,
        selectedBuilderId, selectedMilestoneName, selectedMilestoneImages, selectedMilestoneForDetail,
        selectedBuilder, milestonesStatus, projectProgress, nextPayableMilestone, selectedMilestoneToPay,
        openDialog, closeDialog,
        handleRequestVisit, handleViewProposal, handleViewBuilderProfile, handleAcceptProposal, handleRejectProposal,
        handleSignContract, handleMilestoneClick, handlePayMilestone, handleOpenReviewPopover, handleSaveReview,
        handleOpenDetailPopover, handleCloseDetailPopover,
    };
}

export default useOwnerProjectFlow;
  