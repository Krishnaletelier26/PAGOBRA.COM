
import { useState, useEffect, useCallback } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { loadFromLocalStorage, saveToLocalStorage } from '@/lib/storageUtils';
import { projectMilestonesData } from '@/lib/projectUtils';

// --- Initial State & Mock Data ---
const initialVisitRequests = [
  {
    id: 'visit_1', ownerName: 'Carlos Silva', ownerAddress: 'Camino El Oliveto 450, Talagante',
    houseModel: { name: 'Austral', basePrice: 8200000, imageUrl: 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwxfDB8MXxyYW5kb218MHx8bW9kZXJuJTIwaG91c2UlMjBleHRlcmlvcnx8fHx8fDE3MTQ0NzgyMDM&ixlib=rb-4.0.3&q=80&utm_campaign=api-credit&utm_medium=referral&utm_source=unsplash_source&w=1080' },
    requestedDate: '2025-05-15', requestedTime: '10:00', status: 'new', proposalDetails: null,
  },
  {
    id: 'visit_2', ownerName: 'Ana Martínez', ownerAddress: 'Parcela 12, Lote B, Paine',
    houseModel: { name: 'C-82', basePrice: 8200000, imageUrl: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwxfDB8MXxyYW5kb218MHx8bW9kZXJuJTIwaG91c2V8fHx8fHwxNzE0NDc4MjAw&ixlib=rb-4.0.3&q=80&utm_campaign=api-credit&utm_medium=referral&utm_source=unsplash_source&w=1080' },
    requestedDate: '2025-05-18', requestedTime: '14:30', status: 'new', proposalDetails: null,
  },
];
const initialProjects = [];
const availableAdditionals = [
  { id: 'fosa', name: 'Fosa séptica', price: 550000 }, { id: 'calefont', name: 'Caseta Calefont', price: 180000 },
  { id: 'bano', name: 'Baño químico', price: 120000 }, { id: 'aislante', name: 'Aislante térmico adicional', price: 350000 },
  { id: 'generador', name: 'Generador eléctrico', price: 90000 }, { id: 'luz', name: 'Empalme de luz', price: 300000 },
  { id: 'agua', name: 'Empalme de agua', price: 250000 }, { id: 'alcantarillado', name: 'Empalme de alcantarillado', price: 400000 },
];

// --- Helper Functions ---
const ensureProjectStructure = (project) => {
  const milestones = project.milestones || {};
  projectMilestonesData.forEach(milestoneData => {
    const milestoneName = milestoneData.name;
    if (!milestones[milestoneName]) milestones[milestoneName] = { paid: 0, images: [] };
    else {
      if (typeof milestones[milestoneName].paid === 'undefined') milestones[milestoneName].paid = 0;
      if (!Array.isArray(milestones[milestoneName].images)) milestones[milestoneName].images = [];
    }
  });
  if (!project.imageUrl) project.imageUrl = `https://images.unsplash.com/photo-1518791841217-8f162f1e1131?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwxfDB8MXxyYW5kb218MHx8YnVpbGRpbmdfcHJvZ3Jlc3N8fHx8fHwxNzE0NTAwMDAw&ixlib=rb-4.0.3&q=80&w=1080`;
  if (typeof project.progress === 'undefined') project.progress = 0;
  if (typeof project.review === 'undefined') project.review = null;
  return { ...project, milestones };
};

const formatPrice = (price) => price ? `${price.toLocaleString('es-CL')}` : 'Precio no disponible';

// --- Simulation Helpers ---
const simulateOwnerUpdateBuilder = (requestId, proposalData) => {
    const ownerBuilders = loadFromLocalStorage('ownerBuildersData', []);
    const updatedOwnerBuilders = ownerBuilders.map(builder => {
        // Simplified matching: Find the first builder who can build this model
        if (builder.model === proposalData.modelName) {
            return {
                ...builder,
                status: 'proposal_received',
                proposalDetails: {
                    ...proposalData,
                    builderId: builder.id,
                    builderName: builder.name,
                    builderImageUrl: builder.imageUrl,
                    builderStars: builder.stars,
                    visitRequestId: requestId
                }
            };
        }
        return builder;
    });
    saveToLocalStorage('ownerBuildersData', updatedOwnerBuilders);
};

const simulateOwnerCreateProject = (project) => {
    const ownerProjects = loadFromLocalStorage('ownerProjects', []);
    const updatedOwnerProjects = [...ownerProjects, { ...project, status: 'signed' }];
    saveToLocalStorage('ownerProjects', updatedOwnerProjects);
    saveToLocalStorage('signedProject', project); // Set as current signed project for owner
};

// --- Hook Logic ---
function useConstructorData() {
  const { toast } = useToast();

  // --- State ---
  const [visitRequests, setVisitRequests] = useState(() => loadFromLocalStorage('constructorVisitRequests', initialVisitRequests));
  const [projects, setProjects] = useState(() => loadFromLocalStorage('constructorProjects', initialProjects).map(ensureProjectStructure));
  const [inProgressProjects, setInProgressProjects] = useState([]);
  const [completedProjects, setCompletedProjects] = useState([]);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [isProposalModalOpen, setIsProposalModalOpen] = useState(false);

  // --- Effects for LocalStorage and Derived State ---
  useEffect(() => { saveToLocalStorage('constructorVisitRequests', visitRequests); }, [visitRequests]);
  useEffect(() => {
    saveToLocalStorage('constructorProjects', projects);
    setInProgressProjects(projects.filter(p => p.progress < 100).map(ensureProjectStructure));
    setCompletedProjects(projects.filter(p => p.progress >= 100).map(ensureProjectStructure));
  }, [projects]);

   // Effect to check for accepted proposals and create projects automatically (simulation)
   useEffect(() => {
       const checkAcceptedProposals = () => {
           const currentRequests = loadFromLocalStorage('constructorVisitRequests', initialVisitRequests);
           const acceptedRequests = currentRequests.filter(req => req.status === 'accepted' && req.proposalDetails);

           acceptedRequests.forEach(request => {
               // Check if a project for this request already exists
               const existingProject = projects.find(p => p.client === request.ownerName && p.modelName === request.houseModel.name); // Simple check

               if (!existingProject) {
                   console.log(`Simulating project creation for accepted request: ${request.id}`);
                   const proposalData = request.proposalDetails;
                   const newProject = ensureProjectStructure({
                       id: `proj_${Date.now()}_${request.id.slice(-4)}`,
                       name: `Proyecto ${request.houseModel.name} - ${request.ownerName}`,
                       client: request.ownerName, address: request.ownerAddress,
                       builderName: 'Constructora XYZ', // Assuming this constructor
                       modelName: request.houseModel.name, progress: 0,
                       details: { startDate: new Date().toISOString().split('T')[0], estimatedEndDate: 'Pendiente', totalCost: proposalData.totalPrice },
                       milestones: projectMilestonesData.reduce((acc, m) => ({ ...acc, [m.name]: { paid: 0, images: [] } }), {}),
                       imageUrl: request.houseModel.imageUrl, additionals: proposalData.selectedAdditionals, review: null,
                   });

                   const acuerdoMilestone = projectMilestonesData.find(m => m.name === 'Acuerdo');
                   if (newProject.milestones['Acuerdo'] && acuerdoMilestone) {
                       newProject.milestones['Acuerdo'].paid = 1;
                       newProject.progress = acuerdoMilestone.range[1] || 10;
                   } else {
                       newProject.progress = 10;
                   }

                   setProjects(prev => [...prev, newProject]);
                   simulateOwnerCreateProject(newProject); // Simulate on owner side

                   // Update request status to prevent re-creation (optional, maybe 'project_created')
                   // updateRequestState(request.id, { status: 'project_created' });
               }
           });
       };

       // Check periodically or trigger based on specific events
       const intervalId = setInterval(checkAcceptedProposals, 15000); // Check every 15 seconds
       checkAcceptedProposals(); // Initial check

       return () => clearInterval(intervalId);
   }, [projects]); // Rerun if projects state changes


  // --- State Update Callbacks ---
  const updateRequestState = useCallback((requestId, updates) => {
    setVisitRequests(prev => prev.map(req => req.id === requestId ? { ...req, ...updates } : req));
  }, []);

  const updateProjectData = useCallback((projectId, updates) => {
    setProjects(prevProjects => prevProjects.map(p => p.id === projectId ? ensureProjectStructure({ ...p, ...updates }) : p));
  }, []);

  const getProjectReview = useCallback((projectId) => {
    const project = projects.find(p => p.id === projectId);
    return project?.review || null;
  }, [projects]);

  // --- Action Handlers ---
  const handleOpenProposalModal = useCallback((requestId) => {
    const request = visitRequests.find(req => req.id === requestId);
    if (request) {
      setSelectedRequest(request);
      setIsProposalModalOpen(true);
    }
  }, [visitRequests]);

  const handleSendProposal = useCallback((requestId, proposalData) => {
    const request = visitRequests.find(req => req.id === requestId);
    if (!request) return;

    const fullProposalData = {
        ...proposalData,
        modelName: request.houseModel.name // Add model name for simulation matching
    };

    updateRequestState(requestId, { status: 'proposal_sent', proposalDetails: fullProposalData });
    setIsProposalModalOpen(false);
    setSelectedRequest(null);
    toast({ title: "Propuesta Enviada", description: `Propuesta enviada a ${request.ownerName} por ${formatPrice(proposalData.totalPrice)}.`, variant: "default" });
    simulateOwnerUpdateBuilder(requestId, fullProposalData); // Simulate owner side update
  }, [updateRequestState, toast, visitRequests]); // Added visitRequests dependency

  return {
    visitRequests, inProgressProjects, completedProjects, availableAdditionals,
    selectedRequest, isProposalModalOpen,
    handleOpenProposalModal, handleSendProposal, setIsProposalModalOpen, setSelectedRequest,
    updateProjectData, getProjectReview,
  };
}

export default useConstructorData;
  