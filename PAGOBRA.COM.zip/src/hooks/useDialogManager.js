
import { useState, useCallback } from 'react';

function useDialogManager() {
  const [dialogState, setDialogState] = useState({
    visitRequestOpen: false,
    proposalReviewOpen: false, // Kept for potential direct use, though HomePage manages it now
    proposalViewOpen: false,
    contractViewOpen: false,
    paymentOpen: false,
    photoViewOpen: false,
    builderProfileOpen: false,
    reviewPopoverOpen: false,
    milestoneDetailPopoverOpen: false,
    // Constructor specific dialogs
    proposalCreateOpen: false,
    milestoneProgressUpdateOpen: false,
    milestonePhotoUploadOpen: false,
    clientReviewViewOpen: false,
  });

  // State for selected items needed by dialogs
  const [selectedBuilderId, setSelectedBuilderId] = useState(null);
  const [selectedMilestoneName, setSelectedMilestoneName] = useState(null);
  const [selectedMilestoneImages, setSelectedMilestoneImages] = useState([]);
  const [selectedMilestoneForDetail, setSelectedMilestoneForDetail] = useState(null);
  const [selectedVisitRequest, setSelectedVisitRequest] = useState(null); // For constructor proposal
  const [selectedProjectForDetails, setSelectedProjectForDetails] = useState(null); // For constructor details/review
  const [selectedProjectForReviewView, setSelectedProjectForReviewView] = useState(null); // For constructor review view

  const openDialog = useCallback((dialogName) => setDialogState(prev => ({ ...prev, [dialogName]: true })), []);
  const closeDialog = useCallback((dialogName) => {
      setDialogState(prev => ({ ...prev, [dialogName]: false }));
      // Reset related selections when closing specific dialogs
      if (dialogName === 'proposalViewOpen' || dialogName === 'contractViewOpen' || dialogName === 'builderProfileOpen') {
          setSelectedBuilderId(null);
      }
      if (dialogName === 'paymentOpen' || dialogName === 'photoViewOpen') {
          setSelectedMilestoneName(null);
          setSelectedMilestoneImages([]);
      }
       if (dialogName === 'milestoneDetailPopoverOpen') {
          setSelectedMilestoneForDetail(null);
      }
       if (dialogName === 'proposalCreateOpen') {
           setSelectedVisitRequest(null);
       }
       if (dialogName === 'milestoneProgressUpdateOpen' || dialogName === 'milestonePhotoUploadOpen') {
           setSelectedProjectForDetails(null); // Assuming these use project details
           setSelectedMilestoneName(null);
       }
        if (dialogName === 'clientReviewViewOpen') {
            setSelectedProjectForReviewView(null);
        }

  }, []); // Added dependencies for setters

  return {
    dialogState,
    openDialog,
    closeDialog,

    // Selections and Setters
    selectedBuilderId,
    setSelectedBuilderId,
    selectedMilestoneName,
    setSelectedMilestoneName,
    selectedMilestoneImages,
    setSelectedMilestoneImages,
    selectedMilestoneForDetail,
    setSelectedMilestoneForDetail,
    selectedVisitRequest,
    setSelectedVisitRequest,
    selectedProjectForDetails,
    setSelectedProjectForDetails,
    selectedProjectForReviewView,
    setSelectedProjectForReviewView,
  };
}

export default useDialogManager;
  