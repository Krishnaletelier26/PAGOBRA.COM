
import React, { useState, useEffect } from 'react'; // Added useState, useEffect
import HomeTab from '@/components/home/HomeTab';
// import ProjectsTab from '@/components/home/ProjectsTab'; // Removed ProjectsTab
import ChatTab from '@/components/home/ChatTab';
import ChatView from '@/components/home/ChatView';
import { motion, AnimatePresence } from 'framer-motion';
import { loadFromLocalStorage } from '@/lib/storageUtils'; // Import helper

// Example Mock Chats Data (Replace with actual data source/prop)
const defaultMockChats = [
   { id: 'chat_proj_test_1', name: 'Constructora XYZ', lastMessage: '¡Claro! Lo revisamos mañana.', time: '10:30', unread: 2, projectId: 'proj_test_1' },
   { id: 'support_1', name: 'Soporte Pagobra', lastMessage: '¿En qué podemos ayudarte?', time: 'Ayer', unread: 0 },
];

function OwnerDashboard({ activeTab, setActiveTab, activeChatId, setActiveChatId }) { // Removed userType prop as ProjectsTab is gone
  const [mockChats, setMockChats] = useState([]);
  const [chatSearchTerm, setChatSearchTerm] = useState('');

   // Load chats based on signed projects when component mounts
   useEffect(() => {
     const projects = loadFromLocalStorage('pendingProjects', []);
     const signed = loadFromLocalStorage('hasSignedContract', false);
     const generatedChats = [];

      // Add chat for the signed project if it exists
      if (signed && projects.length > 0) {
          const signedProject = projects[projects.length - 1]; // Assuming last project is the signed one
          if (signedProject && signedProject.builderName) {
             generatedChats.push({
                id: `chat_${signedProject.id}`,
                name: signedProject.builderName,
                lastMessage: 'Revisando últimos detalles...',
                time: '14:05', // Example time
                unread: 1,
                projectId: signedProject.id
             });
          }
      }

      // Add default support chat
      generatedChats.push({ id: 'support_1', name: 'Soporte Pagobra', lastMessage: '¿En qué podemos ayudarte?', time: 'Ayer', unread: 0 });

     setMockChats(generatedChats);
   }, [activeTab]); // Re-run if tab changes, maybe needed if projects state changes? Could refine dependency.


  const renderActiveTab = () => {
    switch (activeTab) {
      case 'inicio':
        return <HomeTab />;
      // case 'proyectos': // Removed case for projects
      //   return <ProjectsTab userType={userType} />;
      case 'chat':
         return <ChatTab
                   chatSearchTerm={chatSearchTerm}
                   setChatSearchTerm={setChatSearchTerm}
                   setActiveChatId={setActiveChatId}
                   mockChats={mockChats} // Pass generated chats
                 />;
      default:
        return <HomeTab />;
    }
  };

   // Find the current chat details for ChatView
  const currentChat = mockChats.find(chat => chat.id === activeChatId);


  return (
    <div className="flex-grow overflow-y-auto pb-16 sm:pb-4"> {/* Adjusted padding bottom */}
      <AnimatePresence mode="wait">
        {activeChatId ? (
          <motion.div
            key="chat-view"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', ease: 'easeInOut', duration: 0.3 }}
            className="h-full flex flex-col" // Ensure ChatView takes full height
          >
             <ChatView
                 chatId={activeChatId}
                 chatName={currentChat?.name || 'Chat'} // Pass chat name
                 onBack={() => setActiveChatId(null)}
              />
          </motion.div>
        ) : (
          <motion.div
            key={activeTab}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="p-0"
          >
            {renderActiveTab()}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default OwnerDashboard;
  