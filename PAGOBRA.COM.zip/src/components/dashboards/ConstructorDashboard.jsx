
import React, { useState, useEffect } from 'react'; // Added useState, useEffect
import ConstructorHomeTab from '@/components/constructor/ConstructorHomeTab';
// import ConstructorProjectsTab from '@/components/constructor/ConstructorProjectsTab'; // Removed ProjectsTab
import ChatTab from '@/components/home/ChatTab'; // Use the generic ChatTab
import ChatView from '@/components/home/ChatView';
import { motion, AnimatePresence } from 'framer-motion';
import { loadFromLocalStorage } from '@/lib/storageUtils'; // Import helper

function ConstructorDashboard({ activeTab, setActiveTab, activeChatId, setActiveChatId }) {
   const [mockChats, setMockChats] = useState([]);
   const [chatSearchTerm, setChatSearchTerm] = useState('');

   // Load chats based on projects constructor is involved in
   useEffect(() => {
       // Fetch projects assigned to this constructor (using localStorage for now)
       const projects = loadFromLocalStorage('pendingProjects', []); // Assuming constructor sees all pending
       const constructorChats = projects.map(project => ({
            id: `chat_${project.id}`,
            name: project.client || `Cliente ${project.id.substring(5,9)}`, // Use client name or generate one
            lastMessage: `Sobre proyecto ${project.modelName || project.name}...`,
            time: 'Hoy', // Example time
            unread: Math.random() > 0.7 ? 1 : 0, // Random unread for demo
            projectId: project.id
       }));

       // Add default support chat
       constructorChats.push({ id: 'support_1', name: 'Soporte Pagobra', lastMessage: '¿Necesitas ayuda?', time: 'Ayer', unread: 0 });

       setMockChats(constructorChats);

   }, [activeTab]); // Re-run if needed

   const renderActiveTab = () => {
    switch (activeTab) {
      case 'inicio':
        return <ConstructorHomeTab />;
      // case 'proyectos': // Removed case for projects
      //   return <ConstructorProjectsTab />;
      case 'chat':
         return <ChatTab
                   chatSearchTerm={chatSearchTerm}
                   setChatSearchTerm={setChatSearchTerm}
                   setActiveChatId={setActiveChatId}
                   mockChats={mockChats} // Pass generated chats
                 />;
      default:
        return <ConstructorHomeTab />;
    }
  };

  // Find the current chat details for ChatView
  const currentChat = mockChats.find(chat => chat.id === activeChatId);

  return (
    <div className="flex-grow overflow-y-auto pb-16 sm:pb-4"> {/* Adjusted padding bottom */}
      <AnimatePresence mode="wait">
        {activeChatId ? (
          <motion.div
            key="chat-view"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', ease: 'easeInOut', duration: 0.3 }}
            className="h-full flex flex-col" // Ensure ChatView takes full height
          >
             <ChatView
                 chatId={activeChatId}
                 chatName={currentChat?.name || 'Chat'} // Pass chat name
                 onBack={() => setActiveChatId(null)}
              />
          </motion.div>
        ) : (
          <motion.div
            key={activeTab}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="p-0" // Remove padding here, add in tabs if needed
          >
            {renderActiveTab()}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default ConstructorDashboard;
  