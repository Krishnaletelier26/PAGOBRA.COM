
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Check, X } from 'lucide-react';

function ProposalViewDialog({ isOpen, setIsOpen, builder, proposal, onAccept, onReject }) {

  if (!builder || !proposal) return null;

  const handleAcceptClick = () => {
    onAccept(builder.id);
    // Parent component (HomeTab) handles closing this and opening contract dialog
  };

  const handleRejectClick = () => {
    onReject(builder.id);
    setIsOpen(false); // Close the dialog on rejection
  };

  // Ensure additionals is an array
  const additionals = Array.isArray(proposal.additionals) ? proposal.additionals : [];

  // Calculate total price safely
  const totalPrice = proposal.basePrice + additionals.reduce((sum, item) => sum + item.price, 0);


  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      {/* Adjusted width to better match the image */}
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          {/* Adjusted title and description */}
          <DialogTitle className="text-xl font-semibold">Revisar Propuesta de {builder.name}</DialogTitle>
           <DialogDescription className="text-sm text-gray-500 pt-1">
             Detalles de la propuesta para el proyecto: Modelo C-82 {/* Assuming fixed model */}
          </DialogDescription>
        </DialogHeader>

        {/* Content area matching the image structure */}
        <div className="py-4 space-y-4">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Resumen Financiero:</h3>

          {/* Base Price */}
          <div className="flex justify-between items-center text-sm text-gray-700">
            <span>Precio Base:</span>
            <span className="font-medium">${proposal.basePrice.toLocaleString('es-CL')}</span>
          </div>

          {/* Additional Services */}
          {additionals.length > 0 && (
            <div className="mt-3 pt-3 border-t border-gray-200">
              <h4 className="text-base font-semibold text-gray-800 mb-2">Servicios Adicionales Incluidos:</h4>
              <div className="space-y-1">
                {additionals.map((item, index) => (
                  <div key={index} className="flex justify-between items-center text-sm text-gray-600">
                    <span>{item.name}</span>
                    <span className="font-medium">+ ${item.price.toLocaleString('es-CL')}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Total Price */}
          <div className="mt-4 pt-3 border-t border-gray-200">
            <div className="flex justify-between items-center text-lg text-primary font-bold">
              <span>Precio Total Propuesto:</span>
              <span>${totalPrice.toLocaleString('es-CL')}</span>
            </div>
          </div>
        </div>

        {/* Footer with Accept/Reject buttons */}
        <DialogFooter className="flex flex-col sm:flex-row gap-2 pt-4">
           {/* Reject Button - Red */}
          <Button variant="destructive" onClick={handleRejectClick} className="w-full order-2 sm:order-1">
            <X className="w-4 h-4 mr-2" /> Rechazar Propuesta
          </Button>
           {/* Accept Button - Green */}
          <Button onClick={handleAcceptClick} className="w-full order-1 sm:order-2 bg-green-600 hover:bg-green-700 text-white">
            <Check className="w-4 h-4 mr-2" /> Aceptar Propuesta
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default ProposalViewDialog;
  