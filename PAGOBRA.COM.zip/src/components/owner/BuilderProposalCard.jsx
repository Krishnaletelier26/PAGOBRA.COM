
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Star, Calendar, FileText, X } from 'lucide-react';
import { motion } from 'framer-motion';

const renderStars = (count) => {
  return (
    <div className="flex text-yellow-400">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className="w-4 h-4 sm:w-5 sm:h-5" // Consistent size
          fill={i < count ? 'currentColor' : 'none'}
        />
      ))}
    </div>
  );
};

const getButtonProps = (builder) => {
  switch (builder.status) {
    case 'initial':
      return { text: 'Solicitar Visita', action: 'request_visit', icon: Calendar, disabled: false, variant: 'default' };
    case 'visit_requested':
      return { text: 'Visita Solicitada', action: null, icon: Calendar, disabled: true, variant: 'outline' };
    case 'proposal_ready':
      return { text: 'Ver Propuesta', action: 'view_proposal', icon: FileText, disabled: false, variant: 'default' };
    case 'rejected':
      return { text: 'Propuesta Rechazada', action: null, icon: X, disabled: true, variant: 'destructive' };
    default:
      return { text: '...', action: null, icon: FileText, disabled: true, variant: 'outline' };
  }
};

function BuilderProposalCard({ builder, onRequestVisit, onViewProposal, onViewProfile }) {
  const { text, icon: Icon, disabled, variant, action } = getButtonProps(builder);

  const handleButtonClick = (e) => {
     e.stopPropagation();
     if (action === 'request_visit') {
        onRequestVisit(builder.id);
     } else if (action === 'view_proposal') {
        onViewProposal(builder.id);
     }
  };

  const handleCardClick = () => {
     onViewProfile(builder.id);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
    >
      <Card
        className="w-full flex items-center p-3 pr-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow duration-200 bg-white cursor-pointer" // Adjusted padding right
        onClick={handleCardClick}
      >
        {/* Image on Left */}
        <img
          className="w-12 h-12 sm:w-16 sm:h-16 object-cover rounded-md mr-3 flex-shrink-0 border" // Smaller image, adjusted margin
          alt={`Logo ${builder.name}`}
          src={builder.imageUrl} />

        {/* Center Content: Name & Price */}
        <div className="flex-grow text-left mr-3">
          <h4 className="font-semibold text-gray-800 text-sm sm:text-base leading-tight">{builder.name}</h4>
          <p className="font-bold text-base sm:text-lg text-primary">
            ${builder.basePrice.toLocaleString('es-CL')}
          </p>
        </div>

        {/* Right Content: Stars & Button */}
        <div className="flex flex-col items-end space-y-1 flex-shrink-0">
           {renderStars(builder.stars)}
           <Button
             size="sm"
             onClick={handleButtonClick}
             disabled={disabled}
             variant={variant || "default"}
             className="text-xs sm:text-sm px-2.5 py-1 h-8" // Adjusted padding/height
           >
             <Icon className="w-3.5 h-3.5 mr-1 sm:mr-1.5" /> {/* Slightly smaller margin */}
             {text}
           </Button>
        </div>
      </Card>
    </motion.div>
  );
}

export default BuilderProposalCard;
  