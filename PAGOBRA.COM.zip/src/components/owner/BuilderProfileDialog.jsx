
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Star, MessageSquare as MessageSquareText, Building } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";

// Star rendering utility
const renderStars = (count, size = 'w-4 h-4') => {
  return (
    <div className="flex text-yellow-400">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={size}
          fill={i < count ? 'currentColor' : 'none'}
        />
      ))}
    </div>
  );
};

function BuilderProfileDialog({ isOpen, setIsOpen, builder }) {
  if (!builder) return null;

  const reviews = builder.reviews || [];
  const completedProjects = builder.completedProjects || [];

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-2xl"> {/* Wider dialog */}
        <DialogHeader className="flex flex-row items-center space-x-4 pb-4 border-b">
           <Avatar className="h-16 w-16 border-2 border-primary">
             <AvatarImage src={builder.imageUrl} alt={builder.name} />
             <AvatarFallback>{builder.name.substring(0, 2).toUpperCase()}</AvatarFallback>
           </Avatar>
           <div className="flex-grow">
             <DialogTitle className="text-2xl font-bold text-primary">{builder.name}</DialogTitle>
             <DialogDescription className="flex items-center space-x-2 pt-1">
               {renderStars(builder.stars, 'w-5 h-5')}
               <span className="text-sm text-gray-500">({reviews.length} reseñas)</span>
             </DialogDescription>
           </div>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh] p-1"> {/* Scrollable content */}
          <div className="py-4 space-y-6 pr-4">

            {/* Reviews Section */}
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-3 flex items-center">
                <MessageSquareText className="w-5 h-5 mr-2 text-primary" /> Reseñas de Clientes
              </h3>
              {reviews.length > 0 ? (
                <div className="space-y-3">
                  {reviews.map((review) => (
                    <Card key={review.id} className="bg-gray-50 border-gray-200">
                      <CardContent className="p-3">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm font-medium text-gray-700">{review.client}</span>
                          {renderStars(review.rating)}
                        </div>
                        <p className="text-sm text-gray-600 italic">"{review.comment}"</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500 text-center py-4">Aún no hay reseñas para esta constructora.</p>
              )}
            </div>

            {/* Completed Projects Section */}
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-3 flex items-center">
                 <Building className="w-5 h-5 mr-2 text-primary" /> Proyectos Completados
              </h3>
              {completedProjects.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {completedProjects.map((project) => (
                    <Card key={project.id} className="overflow-hidden border-gray-200">
                      <div className="aspect-video bg-gray-100">
                        <img 
                            className="w-full h-full object-cover"
                            alt={project.name}
                         src="https://images.unsplash.com/photo-1578245106540-9079f6003657" />
                      </div>
                      <p className="text-xs font-medium text-center p-1.5 bg-gray-50 truncate">{project.name}</p>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500 text-center py-4">No hay proyectos completados para mostrar.</p>
              )}
            </div>

          </div>
        </ScrollArea>

        <DialogFooter className="mt-4 pt-4 border-t">
          <DialogClose asChild>
            <Button variant="outline">Cerrar</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default BuilderProfileDialog;
  