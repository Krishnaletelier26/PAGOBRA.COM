
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Image as ImageIcon } from 'lucide-react'; // Use Lucide icon

function MilestonePhotoViewDialog({ isOpen, setIsOpen, milestoneName, images = [] }) {

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-lg"> {/* Wider dialog for better image view */}
        <DialogHeader>
          <DialogTitle className="flex items-center">
             <ImageIcon className="w-5 h-5 mr-2 text-primary" /> Fotos del Hito: {milestoneName}
          </DialogTitle>
          <DialogDescription>
            Visualiza las fotos de progreso subidas por la constructora.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          {images.length > 0 ? (
            <ScrollArea className="h-[400px] w-full rounded-md border p-4"> {/* Increased height */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4"> {/* Responsive grid */}
                {images.map((imgUrl, index) => (
                  <div key={index} className="relative aspect-square overflow-hidden rounded-lg shadow-sm border">
                     {/* Use img tag directly here as URLs are from localStorage */}
                     <img
                        src={imgUrl} // Use the URL directly
                        className="object-cover w-full h-full transition-transform duration-200 hover:scale-105"
                        alt={`Progreso ${milestoneName} ${index + 1}`}
                        loading="lazy" // Lazy load images
                     />
                  </div>
                ))}
              </div>
            </ScrollArea>
          ) : (
            <p className="text-center text-gray-500 py-8">No hay fotos disponibles para este hito.</p>
          )}
        </div>
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cerrar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default MilestonePhotoViewDialog;
  