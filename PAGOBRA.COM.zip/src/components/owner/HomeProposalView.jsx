
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import BuilderProposalCard from '@/components/owner/BuilderProposalCard.jsx'; // Added .jsx extension
import { AnimatePresence, motion } from 'framer-motion';

function HomeProposalView({ builders, houseModel, handlers }) {
  // Display only the first 3 builders for the new layout
  const displayedBuilders = builders.slice(0, 3);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      {/* House Model Info */}
      <Card className="mb-6 shadow-md border border-blue-100 bg-white overflow-hidden">
        <div className="flex flex-col sm:flex-row">
          <div className="sm:w-1/3 flex-shrink-0">
             <img
              className="w-full h-40 sm:h-full object-cover"
              alt={houseModel.name}
             src={houseModel.imageUrl} />
          </div>
          <div className="p-4 flex-grow">
            <CardTitle className="text-xl text-primary mb-1">{houseModel.name}</CardTitle>
            <CardDescription>{houseModel.description}</CardDescription>
          </div>
        </div>
      </Card>

      {/* Builders List */}
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Propuestas recibidas</h2>
      {displayedBuilders.length > 0 ? (
        <div className="space-y-2"> {/* Reduced spacing */}
          <AnimatePresence>
            {displayedBuilders.map((builder, index) => (
              <BuilderProposalCard
                key={builder.id}
                builder={builder}
                index={index}
                handlers={handlers}
              />
            ))}
          </AnimatePresence>
           {/* Add a note if there are more builders than shown */}
           {builders.length > 3 && (
             <p className="text-xs text-center text-gray-500 mt-3">
               Mostrando {displayedBuilders.length} de {builders.length} propuestas.
             </p>
           )}
        </div>
      ) : (
        <p className="text-center text-gray-500 mt-8">No hay propuestas activas.</p>
      )}
    </motion.div>
  );
}

export default HomeProposalView;
  