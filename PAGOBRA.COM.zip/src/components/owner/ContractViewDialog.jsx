
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area'; // Import ScrollArea
import { FileSignature } from 'lucide-react';

// Mock contract text generation
const generateContractText = (builder, proposal) => `
CONTRATO DE CONSTRUCCIÓN

PARTES:
Propietario: [Nombre Propietario Placeholder], RUT: [RUT Propietario Placeholder], Dirección: [Dirección Propietario Placeholder]
Constructora: ${builder.name}, RUT: [RUT Constructora Placeholder], Dirección: [Dirección Constructora Placeholder]

OBJETO:
Construcción de vivienda modelo [Modelo Placeholder] según especificaciones acordadas.

RESPONSABILIDADES:
La Constructora se compromete a ejecutar la obra según los planos y especificaciones técnicas, utilizando materiales de calidad y personal calificado. El Propietario se compromete a facilitar el acceso al terreno y realizar los pagos según lo acordado.

VALOR DEL TRABAJO:
El valor total de la obra asciende a $${proposal.totalPrice.toLocaleString('es-CL')}. Los pagos se realizarán según el avance de los hitos definidos.

OBRAS MAL EJECUTADAS:
La Constructora será responsable de corregir, sin costo adicional para el Propietario, cualquier defecto o vicio de construcción que se presente dentro del plazo de garantía.

PLAZOS DE LA OBRA:
Fecha de Inicio Estimada: [Fecha Inicio Placeholder]
Fecha de Término Estimada: [Fecha Término Placeholder]
El cronograma detallado se adjunta como Anexo 1.

GARANTÍA:
La Constructora ofrece una garantía de [Plazo Garantía Placeholder] años para la estructura y [Plazo Garantía Terminaciones Placeholder] año para las terminaciones, contados desde la recepción final de la obra.

CONFIDENCIALIDAD:
Ambas partes acuerdan mantener la confidencialidad de la información técnica y comercial relacionada con este contrato.

RESOLUCIÓN DE CONFLICTOS:
Cualquier diferencia será resuelta mediante negociación directa. De no lograr acuerdo, se someterá a los tribunales ordinarios de justicia.

Fecha: ${new Date().toLocaleDateString('es-CL')}
`;

function ContractViewDialog({ isOpen, setIsOpen, builder, proposal, onSign }) {
  const [termsAccepted, setTermsAccepted] = useState(false);

  if (!builder || !proposal) return null;

  const contractText = generateContractText(builder, proposal);

  const handleSignClick = () => {
    if (termsAccepted) {
      onSign(builder.id);
      // setIsOpen(false); // Parent handles closing
    }
  };

  return (
    // Increase max-width and allow more height
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-2xl md:max-w-3xl max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Contrato de Construcción - {builder.name}</DialogTitle>
          <DialogDescription>
            Por favor, lee detenidamente los términos del contrato antes de firmar.
          </DialogDescription>
        </DialogHeader>
        {/* Make the contract text scrollable */}
        <ScrollArea className="flex-grow border rounded-md p-4 my-4 whitespace-pre-wrap text-xs">
           {contractText}
        </ScrollArea>
        <div className="flex items-center space-x-2 mt-auto pt-4 border-t">
          <Checkbox
            id="terms"
            checked={termsAccepted}
            onCheckedChange={setTermsAccepted}
          />
          <Label htmlFor="terms" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
            Acepto términos y condiciones del contrato.
          </Label>
        </div>
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
          <Button
            onClick={handleSignClick}
            disabled={!termsAccepted}
          >
            <FileSignature className="w-4 h-4 mr-2" /> Firmar Contrato
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default ContractViewDialog;
  