
import React, { useState } from 'react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

function StarRating({ rating, setRating }) {
  return (
    <div className="flex space-x-1">
      {[...Array(5)].map((_, index) => {
        const ratingValue = index + 1;
        return (
          <button
            type="button"
            key={ratingValue}
            onClick={() => setRating(ratingValue)}
            className="focus:outline-none"
          >
            <Star
              className={cn(
                "w-6 h-6 cursor-pointer transition-colors duration-150",
                ratingValue <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300 hover:text-yellow-300"
              )}
            />
          </button>
        );
      })}
    </div>
  );
}

function ReviewPopover({ isOpen, setIsOpen, onSubmit, trigger }) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ rating, comment });
    setRating(0); // Reset after submit
    setComment('');
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        {trigger}
      </PopoverTrigger>
      <PopoverContent className="w-80">
        <form onSubmit={handleSubmit} className="grid gap-4">
          <div className="space-y-2">
            <h4 className="font-medium leading-none">Escribe tu Reseña</h4>
            <p className="text-sm text-muted-foreground">
              Comparte tu experiencia con la constructora.
            </p>
          </div>
          <div className="grid gap-2">
            <div className="grid grid-cols-3 items-center gap-4">
              <Label htmlFor="rating" className="col-span-1">Calificación</Label>
              <div className="col-span-2">
                 <StarRating rating={rating} setRating={setRating} />
              </div>
            </div>
            <div className="grid grid-cols-3 items-start gap-4">
              <Label htmlFor="comment" className="col-span-1 pt-2">Comentario</Label>
              <Textarea
                id="comment"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Describe tu experiencia..."
                className="col-span-2 h-24"
              />
            </div>
          </div>
           <Button type="submit" size="sm" disabled={rating === 0}>Enviar Reseña</Button>
        </form>
      </PopoverContent>
    </Popover>
  );
}

export default ReviewPopover;
  