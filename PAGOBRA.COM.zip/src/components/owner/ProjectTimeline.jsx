
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import MilestoneListDisplay from '@/components/shared/MilestoneListDisplay';
import PaymentDialog from '@/components/home/PaymentDialog';
import MilestonePhotoViewDialog from '@/components/owner/MilestonePhotoViewDialog';
import ReviewPopover from '@/components/owner/ReviewPopover';
import { useToast } from '@/components/ui/use-toast';
import { findNextActionableMilestone, projectMilestonesData } from '@/lib/projectUtils';
import { Button } from '@/components/ui/button';
import { CheckCircle, AlertCircle, Calendar, MessageSquare } from 'lucide-react';

function ProjectTimeline({
    projectData,
    onOpenPaymentDialog, // Keep this prop name consistent
    onClosePaymentDialog,
    isPaymentModalOpen,
    selectedMilestoneToPay, // Keep this to know which milestone the modal is for
    onPaymentSuccess,
    onOpenPhotoViewDialog,
    onClosePhotoViewDialog,
    isPhotoViewModalOpen,
    selectedMilestoneForView,
    milestoneImages,
    onSaveReview,
    isMilestoneDetailPopoverOpen,
    selectedMilestoneForDetail,
    onOpenMilestoneDetailPopover,
    onCloseMilestoneDetailPopover,
}) {
    const { toast } = useToast();
    // Removed currentlySelectedMilestoneForPayment state
    const [isReviewPopoverOpen, setIsReviewPopoverOpen] = useState(false);
    const [milestoneForPaymentModal, setMilestoneForPaymentModal] = useState(null); // State to hold milestone for the modal

    if (!projectData) {
        return <p className="text-center text-gray-500 mt-8">Cargando información del proyecto...</p>;
    }

    const milestonesStatus = projectData.milestones || {};
    const nextPayableMilestone = findNextActionableMilestone(projectData.progress, milestonesStatus);
    const isProjectComplete = projectData.progress >= 100;

    // Removed handleCheckboxChange

    // Renamed handleProceedToPayment to handlePayButtonClick
    const handlePayButtonClick = (milestone) => {
        // Check if previous milestone is complete (redundant check, but safe)
        const previousMilestoneIndex = projectMilestonesData.findIndex(m => m.name === milestone.name) - 1;
        if (previousMilestoneIndex >= 0) {
            const previousMilestone = projectMilestonesData[previousMilestoneIndex];
            if (projectData.progress < previousMilestone.range[1]) {
                 toast({
                    title: "Acción Bloqueada",
                    description: `Debes completar el hito "${previousMilestone.name}" antes de pagar por "${milestone.name}".`,
                    variant: "destructive",
                 });
                 return;
            }
        }
        // Check if it's the actual next payable milestone (redundant check, but safe)
        if (nextPayableMilestone && milestone.name === nextPayableMilestone.name) {
            setMilestoneForPaymentModal(milestone); // Set the milestone for the modal
            onOpenPaymentDialog(milestone); // Call the prop to open the modal (passing milestone info)
        } else {
             toast({
                title: "Hito Incorrecto",
                description: `El próximo hito a pagar es "${nextPayableMilestone?.name || 'ninguno'}".`,
                variant: "destructive",
             });
        }
    };

    const handleMilestonePhotoClick = (milestoneName, images) => {
         onOpenPhotoViewDialog(milestoneName, images);
    };

    const handleOpenReview = () => {
        setIsReviewPopoverOpen(true);
    };

    const handleInternalSaveReview = (reviewData) => {
        if (onSaveReview) {
            onSaveReview(projectData.id, projectData.builderName, reviewData);
        }
        setIsReviewPopoverOpen(false);
    };

    const handleClosePayment = () => {
        setMilestoneForPaymentModal(null); // Clear milestone when closing modal
        onClosePaymentDialog(); // Call original close handler
    };

    const handleConfirmPayment = () => {
        if (milestoneForPaymentModal) {
            onPaymentSuccess(milestoneForPaymentModal.name); // Pass name
            setMilestoneForPaymentModal(null); // Clear after success
            // onClosePaymentDialog(); // PaymentDialog closes itself via onConfirmPayment -> onPaymentSuccess -> closePaymentDialog in hook
        }
    };


  return (
    <div className="space-y-6">
        {/* Project Overview Card */}
         <Card className="shadow-md border border-blue-100 bg-white overflow-hidden">
             <div className="relative">
                <img 
                    className="w-full h-48 object-cover"
                    alt={projectData.modelName || 'Modelo de Casa'}
                  src="https://images.unsplash.com/photo-1683576235070-1f7685af03dd" />
             </div>
             <div className="p-4">
               <CardTitle className="text-xl text-primary mb-1">{projectData.modelName || projectData.name}</CardTitle>
               <CardDescription className="text-sm">{projectData.description || 'Descripción del modelo.'}</CardDescription>
               <CardDescription className="text-sm mt-1">Constructora: <span className='font-medium'>{projectData.builderName}</span></CardDescription>
             </div>
         </Card>

       {/* Milestone Timeline Card */}
       <Card className="shadow-lg border border-gray-200 bg-white">
           <CardHeader className="flex flex-row items-center space-x-3 pb-4">
                <Calendar className="w-6 h-6 text-primary" />
                <div>
                    <CardTitle className="text-lg font-semibold text-primary">Cronograma del Proyecto</CardTitle>
                    <CardDescription className="text-sm">Sigue el avance y realiza los pagos.</CardDescription>
                </div>
           </CardHeader>
           <CardContent className="pb-4 px-4 sm:px-6">
                <MilestoneListDisplay
                    className="mt-2"
                    overallProgress={projectData.progress}
                    milestonesStatus={milestonesStatus}
                    showPaymentFeatures={true}
                    // Removed selectedMilestoneName, onCheckboxChange
                    onMilestonePhotoClick={handleMilestonePhotoClick}
                    onPayButtonClick={handlePayButtonClick} // Pass the new handler
                    userType="owner"
                    isDetailPopoverOpen={isMilestoneDetailPopoverOpen}
                    selectedMilestoneForDetail={selectedMilestoneForDetail}
                    onOpenDetailPopover={onOpenMilestoneDetailPopover}
                    onCloseDetailPopover={onCloseMilestoneDetailPopover}
                />

                {/* Payment Action Area - Simplified/Removed */}
                <div className="mt-6 pt-4 border-t">
                  {isProjectComplete ? (
                     <div className="flex flex-col sm:flex-row items-center justify-center text-center sm:justify-between gap-3">
                        <div className="flex items-center text-sm text-green-600">
                            <CheckCircle className="w-4 h-4 mr-2 flex-shrink-0" />
                            <span>¡Proyecto completado satisfactoriamente!</span>
                        </div>
                        <ReviewPopover
                           isOpen={isReviewPopoverOpen}
                           setIsOpen={setIsReviewPopoverOpen}
                           onSubmit={handleInternalSaveReview}
                           trigger={
                               <Button variant="outline" size="sm" onClick={handleOpenReview}>
                                   <MessageSquare className="w-4 h-4 mr-2" />
                                   Escribir Reseña
                               </Button>
                           }
                         />
                     </div>
                  ) : !nextPayableMilestone ? (
                     // Condition when project not complete but no milestone is payable yet (waiting for progress)
                     <div className="flex items-center justify-center text-sm text-orange-600 py-2">
                        <AlertCircle className="w-4 h-4 mr-2" />
                        <span>Esperando avance para el próximo pago.</span>
                     </div>
                  ) : null /* No general button needed if payment is per-milestone */}
                </div>
           </CardContent>
       </Card>

        {/* Modals */}
        {milestoneForPaymentModal && (
            <PaymentDialog
                isOpen={isPaymentModalOpen && selectedMilestoneToPay?.name === milestoneForPaymentModal.name} // Ensure modal matches the intended milestone
                setIsOpen={handleClosePayment} // Use custom close handler
                milestone={milestoneForPaymentModal}
                onConfirmPayment={handleConfirmPayment} // Use custom confirm handler
            />
        )}

        {selectedMilestoneForView && (
            <MilestonePhotoViewDialog
                isOpen={isPhotoViewModalOpen}
                setIsOpen={onClosePhotoViewDialog}
                milestoneName={selectedMilestoneForView}
                images={milestoneImages}
            />
      )}
    </div>
  );
}

export default ProjectTimeline;
  