
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Check, X } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

function ProposalReviewDialog({ isOpen, setIsOpen, proposal, onAction }) {
  const { toast } = useToast();

  if (!proposal) return null;

  const handleAccept = () => {
    onAction(proposal.id, true); // Notify parent that proposal is accepted
    toast({
      title: "Propuesta Aceptada",
      description: `Has aceptado la propuesta de ${proposal.builderName}.`,
      variant: "default", // Consider a 'success' variant if available
      duration: 5000,
    });
    // No need to setIsOpen(false) here, parent handles it via onAction
  };

  const handleReject = () => {
    onAction(proposal.id, false); // Notify parent that proposal is rejected
    toast({
      title: "Propuesta Rechazada",
      description: `Has rechazado la propuesta de ${proposal.builderName}.`,
      variant: "destructive",
      duration: 5000,
    });
     // No need to setIsOpen(false) here, parent handles it via onAction
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Revisar Propuesta de {proposal.builderName}</DialogTitle>
          <DialogDescription>
            Detalles de la propuesta para el proyecto: {proposal.projectName}
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-4">
          {/* Proposal Details */}
          <div>
            <h4 className="font-semibold text-gray-800 mb-2">Resumen Financiero:</h4>
            <div className="flex justify-between text-sm">
              <span>Precio Base:</span>
              <span>${proposal.basePrice.toLocaleString('es-CL')}</span>
            </div>
            {proposal.additionals.length > 0 && (
              <div className="mt-2 border-t pt-2">
                <p className="text-sm font-medium text-gray-600 mb-1">Servicios Adicionales Incluidos:</p>
                <ul className="list-disc list-inside space-y-1">
                  {proposal.additionals.map((item, index) => (
                    <li key={index} className="flex justify-between text-sm text-gray-600">
                      <span>{item.name}</span>
                      <span>+ ${item.price.toLocaleString('es-CL')}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
             <div className="flex justify-between text-lg font-bold text-primary mt-3 border-t pt-2">
              <span>Precio Total Propuesto:</span>
              <span>${proposal.totalPrice.toLocaleString('es-CL')}</span>
            </div>
          </div>

          {/* Add other relevant details if necessary */}

        </div>
        <DialogFooter className="flex flex-col sm:flex-row gap-2">
           <Button variant="destructive" onClick={handleReject} className="w-full sm:w-auto">
              <X className="w-4 h-4 mr-2" /> Rechazar Propuesta
            </Button>
          <Button onClick={handleAccept} className="w-full sm:w-auto bg-green-600 hover:bg-green-700">
             <Check className="w-4 h-4 mr-2" /> Aceptar Propuesta
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default ProposalReviewDialog;
  