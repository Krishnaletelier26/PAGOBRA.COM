
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from 'lucide-react';

function VisitRequestDialog({ isOpen, setIsOpen, builder, onSubmit }) {
  const [visitDate, setVisitDate] = useState('');
  const [visitTime, setVisitTime] = useState('');

  if (!builder) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    // Basic validation
    if (!visitDate || !visitTime) {
      // Consider adding a toast message for validation error
      console.error("Date and time are required");
      return;
    }
    onSubmit(builder.id, { date: visitDate, time: visitTime });
    // Reset fields after submit
    setVisitDate('');
    setVisitTime('');
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Solicitar Visita con {builder.name}</DialogTitle>
          <DialogDescription>
            Selecciona una fecha y hora preferida para la visita técnica. La constructora confirmará la disponibilidad.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="py-4 space-y-4">
            <div>
              <Label htmlFor="visit-date">Fecha Preferida</Label>
              <Input
                id="visit-date"
                type="date"
                value={visitDate}
                onChange={(e) => setVisitDate(e.target.value)}
                required
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="visit-time">Hora Preferida</Label>
              <Input
                id="visit-time"
                type="time"
                value={visitTime}
                onChange={(e) => setVisitTime(e.target.value)}
                required
                className="mt-1"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
            <Button type="submit">
              <Calendar className="w-4 h-4 mr-2" /> Enviar Solicitud
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default VisitRequestDialog;
  