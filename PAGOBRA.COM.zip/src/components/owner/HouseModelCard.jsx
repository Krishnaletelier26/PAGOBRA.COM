
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

function HouseModelCard({ model }) {
  if (!model) return null;

  return (
    <Card className="shadow-md border border-gray-200 overflow-hidden bg-white">
      <CardContent className="p-4 flex items-center space-x-4">
        <img 
            class="w-16 h-16 object-cover rounded-md border flex-shrink-0"
            alt={`Imagen ${model.name}`}
         src="https://images.unsplash.com/photo-1545235658-0a7893afc83c" />
        <div className="flex-grow">
          <h3 className="text-lg font-semibold text-primary">{model.name}</h3>
          <p className="text-sm text-gray-600">{model.description}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default HouseModelCard;
  