
import React from 'react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Info, CheckCircle, Clock, DollarSign, Image as ImageIcon } from 'lucide-react'; // Changed Camera to ImageIcon
import { cn } from '@/lib/utils';
import { calculateMilestoneProgress, getMilestoneStatusText } from '@/lib/projectUtils';

function MilestoneDetailPopover({
  milestone,
  milestoneDetails,
  overallProgress,
  trigger,
  isOpen,
  onOpenChange
}) {
  if (!milestone) return null;

  const milestoneProgress = calculateMilestoneProgress(milestone, overallProgress);
  const statusText = getMilestoneStatusText(milestone, milestoneProgress, milestoneDetails);
  const images = milestoneDetails?.images || [];
  const isCompleted = milestoneProgress === 100;
  const isPaid = milestoneDetails?.paid > 0;
  const isInProgressOrPaid = isPaid || (milestoneProgress > 0 && milestoneProgress < 100); // Combine paid and in progress for orange color

  // Updated Color Logic for Popover text
  const statusColor = isCompleted ? "text-green-600" : isInProgressOrPaid ? "text-orange-600" : "text-gray-800";
  const paymentColor = isPaid ? "text-green-600" : "text-orange-600";


  return (
    <Popover open={isOpen} onOpenChange={onOpenChange}>
      <PopoverTrigger asChild>{trigger}</PopoverTrigger>
      <PopoverContent className="w-64 sm:w-72 p-0" sideOffset={5}>
        <div className="p-4 border-b">
          <h4 className="font-semibold text-sm flex items-center">
            <Info className="w-4 h-4 mr-2 text-primary" />
            Detalle: {milestone.name}
          </h4>
        </div>
        <div className="p-4 space-y-3 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center">
              <Clock className="w-3.5 h-3.5 mr-1.5" /> Estado:
            </span>
            <span className={cn("font-medium", statusColor)}> {/* Use updated color */}
              {statusText}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center">
              <DollarSign className="w-3.5 h-3.5 mr-1.5" /> Pago:
            </span>
            <span className={cn("font-medium", paymentColor)}> {/* Use updated color */}
              {isPaid ? 'Realizado' : 'Pendiente'}
            </span>
          </div>

          <div>
            <span className="text-gray-600 block mb-1">Progreso del Hito:</span>
            <div className="flex items-center space-x-2">
              <Progress value={milestoneProgress} className="h-2 flex-grow" />
              <span className="font-medium text-xs w-10 text-right">{milestoneProgress}%</span>
            </div>
          </div>

          {images.length > 0 && (
            <div>
              <span className="text-gray-600 flex items-center mb-1.5">
                 <ImageIcon className="w-3.5 h-3.5 mr-1.5" /> Fotos Recientes: {/* Changed Icon */}
              </span>
              <ScrollArea className="h-[60px] w-full rounded border p-1">
                 <div className="flex space-x-1.5">
                    {images.slice(0, 5).map((imgUrl, index) => (
                       <img
                          key={index}
                          src={imgUrl}
                          alt={`Thumb ${index}`}
                          className="h-12 w-12 object-cover rounded-sm flex-shrink-0"
                          loading="lazy"
                       />
                    ))}
                 </div>
              </ScrollArea>
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

export default MilestoneDetailPopover;
  