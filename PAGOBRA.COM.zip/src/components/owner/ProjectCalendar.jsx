
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Calendar as CalendarIcon } from 'lucide-react';

function ProjectCalendar({ projectData }) {
  // This component is no longer the interactive calendar.
  // It can be kept as a placeholder or removed if ProjectTimeline fully replaces it.
  // For now, let's show a simple message.

  if (!projectData) {
    return <p className="text-center text-gray-500">No hay información del proyecto disponible.</p>;
  }

  return (
    <Card className="shadow-lg border border-gray-200 bg-white overflow-hidden">
      <CardHeader>
        <CardTitle className="flex items-center text-xl font-semibold text-primary">
          <CalendarIcon className="w-5 h-5 mr-2" />
          Resumen del Proyecto
        </CardTitle>
        <CardDescription>Progreso general de tu proyecto.</CardDescription>
      </CardHeader>
      <CardContent>
         <p className="text-center text-muted-foreground py-4">(Aquí se mostrará el cronograma del proyecto)</p>
         {/* Placeholder content - The actual timeline is now in ProjectTimeline.jsx */}
         <p>Proyecto: {projectData.name}</p>
         <p>Progreso: {projectData.progress}%</p>
         <p>Constructor: {projectData.builderName}</p>
      </CardContent>
    </Card>
  );
}

export default ProjectCalendar;
  