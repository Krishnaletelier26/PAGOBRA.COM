
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import ProjectCalendar from '@/components/owner/ProjectCalendar.jsx';
import { motion } from 'framer-motion';

function HomeProjectView({ signedProjectData, houseModel }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      {/* House Model Info */}
      <Card className="mb-6 shadow-md border border-blue-100 bg-white overflow-hidden">
        <div className="flex flex-col sm:flex-row">
          <div className="sm:w-1/3 flex-shrink-0">
            <img
              className="w-full h-40 sm:h-full object-cover"
              alt={houseModel.name}
              src={signedProjectData?.imageUrl || houseModel.imageUrl}
            />
          </div>
          <div className="p-4 flex-grow">
            <CardTitle className="text-xl text-primary mb-1">{signedProjectData?.name || houseModel.name}</CardTitle>
            <CardDescription>{houseModel.description}</CardDescription>
            {signedProjectData && <p className='text-sm mt-2 text-gray-600'>Constructora: {signedProjectData.builderName}</p>}
          </div>
        </div>
      </Card>

      {/* Project Calendar */}
      <ProjectCalendar projectData={signedProjectData} />
    </motion.div>
  );
}

export default HomeProjectView;
  