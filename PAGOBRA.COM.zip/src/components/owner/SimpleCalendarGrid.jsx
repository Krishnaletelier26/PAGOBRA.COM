
import React from 'react';
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"; // Assuming Tooltip exists

// Helper to get days in a month
const getDaysInMonth = (year, month) => {
  return new Date(year, month + 1, 0).getDate();
};

// Helper to get the first day of the month (0=Sun, 1=Mon, ...)
const getFirstDayOfMonth = (year, month) => {
  return new Date(year, month, 1).getDay();
};

const monthNames = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
const dayNames = ["Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sá"];

function SimpleCalendarGrid({ events = [], year = new Date().getFullYear(), month = new Date().getMonth() }) {
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);

  // Create an array representing the calendar grid
  const calendarGrid = [];
  let dayCounter = 1;

  // Calculate total cells needed (including empty cells at start/end)
  const totalCells = Math.ceil((firstDay + daysInMonth) / 7) * 7;

  for (let i = 0; i < totalCells; i++) {
    if (i < firstDay || dayCounter > daysInMonth) {
      calendarGrid.push(null); // Empty cell
    } else {
      const currentDateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayCounter).padStart(2, '0')}`;
      const eventsOnDay = events.filter(event => event.date === currentDateStr);
      calendarGrid.push({ day: dayCounter, events: eventsOnDay });
      dayCounter++;
    }
  }

  // Tooltip needs a Provider wrapper
   if (!TooltipProvider) {
    console.warn("TooltipProvider component not found. Tooltips may not work.");
    // Provide a fallback or skip tooltips
  }
  const TooltipWrapper = TooltipProvider || React.Fragment;


  return (
    <TooltipWrapper>
      <div className="p-4 border rounded-lg bg-white shadow-sm">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-lg font-semibold text-primary">{monthNames[month]} {year}</h3>
          {/* Add Prev/Next month buttons later if needed */}
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-xs font-medium text-gray-500 mb-2">
          {dayNames.map(day => <div key={day}>{day}</div>)}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {calendarGrid.map((cell, index) => (
            <div
              key={index}
              className={cn(
                "h-12 sm:h-16 border border-gray-100 rounded flex flex-col items-center justify-start p-1 text-xs sm:text-sm relative",
                !cell && "bg-gray-50", // Empty cell style
                cell && "bg-white"
              )}
            >
              {cell && (
                <>
                  <span className="font-medium text-gray-700">{cell.day}</span>
                  {cell.events.length > 0 && (
                    <div className="mt-1 flex flex-wrap justify-center gap-0.5">
                       {cell.events.slice(0, 2).map((event, idx) => ( // Show max 2 dots
                        <Tooltip key={idx} delayDuration={100}>
                           {TooltipTrigger && <TooltipTrigger asChild>
                            <span className="w-1.5 h-1.5 bg-blue-500 rounded-full cursor-default"></span>
                           </TooltipTrigger>}
                           {TooltipContent && <TooltipContent className="text-xs p-1">
                            <p>{event.event}</p>
                          </TooltipContent>}
                        </Tooltip>
                      ))}
                       {cell.events.length > 2 && ( // Indicate more events
                         <Tooltip delayDuration={100}>
                           {TooltipTrigger && <TooltipTrigger asChild>
                             <span className="w-1.5 h-1.5 bg-gray-400 rounded-full cursor-default"></span>
                           </TooltipTrigger>}
                           {TooltipContent && <TooltipContent className="text-xs p-1">
                             <p>+{cell.events.length - 2} más eventos</p>
                           </TooltipContent>}
                         </Tooltip>
                       )}
                    </div>
                  )}
                </>
              )}
            </div>
          ))}
        </div>
      </div>
    </TooltipWrapper>
  );
}

export default SimpleCalendarGrid;
  