
import React from 'react';
import { motion } from 'framer-motion';
import VisitRequestDialog from '@/components/owner/VisitRequestDialog';
import ProposalViewDialog from '@/components/owner/ProposalViewDialog';
import ContractViewDialog from '@/components/owner/ContractViewDialog';
import BuilderProfileDialog from '@/components/owner/BuilderProfileDialog';
import ProjectTimeline from '@/components/owner/ProjectTimeline';
import useOwnerProjectFlow from '@/hooks/useOwnerProjectFlow';
import BuilderProposalCard from '@/components/owner/BuilderProposalCard';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { houseModel } from '@/lib/mockData';


function ProposalSelectionView({ builders, onRequestVisit, onViewProposal, onViewProfile }) {
  return (
    <>
      <Card className="mb-6 shadow-md border border-blue-100 bg-white overflow-hidden">
        <div className="flex flex-col sm:flex-row">
          <div className="sm:w-1/3 flex-shrink-0">
             <img 
                className="w-full h-40 sm:h-full object-cover"
                alt={houseModel.name}
              src="https://images.unsplash.com/photo-1698302662805-9d721be98ddd" />
          </div>
          <div className="p-4 flex-grow">
            <CardTitle className="text-xl text-primary mb-1">{houseModel.name}</CardTitle>
            <CardDescription>{houseModel.description}</CardDescription>
          </div>
        </div>
      </Card>

      <h2 className="text-xl font-semibold text-gray-800 mb-4">Propuestas recibidas</h2>
       {builders.length > 0 ? (
         <div className="space-y-4">
            {builders.map((builder) => (
              <BuilderProposalCard
                key={builder.id}
                builder={builder}
                onRequestVisit={onRequestVisit}
                onViewProposal={onViewProposal}
                onViewProfile={onViewProfile}
              />
            ))}
         </div>
       ) : (
         <p className="text-center text-gray-500 mt-8">No hay propuestas disponibles.</p>
       )}
    </>
  );
}


function HomeTab() {
   const {
    // State
    builders,
    projectSigned,
    signedProjectData,
    selectedBuilder,
    isVisitDialogOpen,
    isProposalDialogOpen,
    isContractDialogOpen,
    isProfileDialogOpen,
    isPaymentModalOpen,
    selectedMilestoneToPay,
    isPhotoViewModalOpen,
    selectedMilestoneForView,
    milestoneImages,
    isMilestoneDetailPopoverOpen, // Get popover state
    selectedMilestoneForDetail, // Get selected milestone for popover

    // Actions
    updateProjectState,

    // Dialog Openers/Closers
    handleRequestVisit,
    handleViewProposal,
    handleViewProfile,
    openPaymentDialog,
    openPhotoViewDialog,
    openMilestoneDetailPopover, // Get popover opener
    setIsVisitDialogOpen,
    setIsProposalDialogOpen,
    setIsContractDialogOpen,
    setIsProfileDialogOpen,
    setIsPaymentModalOpen,
    setIsPhotoViewModalOpen,
    setIsMilestoneDetailPopoverOpen, // Get popover setter
    setSelectedBuilderId,

    // Form/Action Handlers
    handleVisitSubmitted,
    handleAcceptProposal,
    handleRejectProposal,
    handleSignContract,
    handlePaymentSuccess,
    handleSaveReview,
  } = useOwnerProjectFlow();

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 sm:p-6">
      {projectSigned ? (
        <ProjectTimeline
            projectData={signedProjectData}
            onOpenPaymentDialog={openPaymentDialog}
            onClosePaymentDialog={() => setIsPaymentModalOpen(false)}
            isPaymentModalOpen={isPaymentModalOpen}
            selectedMilestoneToPay={selectedMilestoneToPay}
            onPaymentSuccess={handlePaymentSuccess}
            onOpenPhotoViewDialog={openPhotoViewDialog}
            onClosePhotoViewDialog={() => setIsPhotoViewModalOpen(false)}
            isPhotoViewModalOpen={isPhotoViewModalOpen}
            selectedMilestoneForView={selectedMilestoneForView}
            milestoneImages={milestoneImages}
            onSaveReview={handleSaveReview}
            // Pass popover props
            isMilestoneDetailPopoverOpen={isMilestoneDetailPopoverOpen}
            selectedMilestoneForDetail={selectedMilestoneForDetail}
            onOpenMilestoneDetailPopover={openMilestoneDetailPopover}
            onCloseMilestoneDetailPopover={() => setIsMilestoneDetailPopoverOpen(false)}
        />
      ) : (
        <ProposalSelectionView
          builders={builders}
          onRequestVisit={handleRequestVisit}
          onViewProposal={handleViewProposal}
          onViewProfile={handleViewProfile}
        />
      )}

      {/* Dialogs for pre-project flow */}
      {selectedBuilder && !projectSigned && (
        <>
          <VisitRequestDialog
            isOpen={isVisitDialogOpen}
            setIsOpen={(open) => { setIsVisitDialogOpen(open); if (!open) setSelectedBuilderId(null); }}
            builder={selectedBuilder}
            onSubmit={handleVisitSubmitted}
          />
          <ProposalViewDialog
            isOpen={isProposalDialogOpen}
            setIsOpen={(open) => { setIsProposalDialogOpen(open); if (!open) setSelectedBuilderId(null); }}
            builder={selectedBuilder}
            proposal={selectedBuilder.proposalDetails}
            onAccept={handleAcceptProposal}
            onReject={handleRejectProposal}
          />
           <ContractViewDialog
            isOpen={isContractDialogOpen}
            setIsOpen={(open) => { setIsContractDialogOpen(open); if (!open) setSelectedBuilderId(null); }}
            builder={selectedBuilder}
            proposal={selectedBuilder.proposalDetails}
            onSign={handleSignContract}
          />
           <BuilderProfileDialog
             isOpen={isProfileDialogOpen}
             setIsOpen={(open) => { setIsProfileDialogOpen(open); if (!open) setSelectedBuilderId(null); }}
             builder={selectedBuilder}
           />
        </>
      )}
       {/* Payment and PhotoView dialogs are now handled inside ProjectTimeline */}
       {/* Review Popover is also handled inside ProjectTimeline */}
       {/* Milestone Detail Popover is rendered inline via MilestoneItem */}

    </motion.div>
  );
}

export default HomeTab;
  