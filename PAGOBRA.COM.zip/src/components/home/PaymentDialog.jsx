
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { CreditCard, Smartphone, Wallet, Landmark } from 'lucide-react'; // Import relevant icons
import { cn } from '@/lib/utils';

// Component for Payment Method Option Button
const PaymentOption = ({ icon: Icon, label, onClick }) => (
  <button
    onClick={onClick}
    className={cn(
      "flex flex-col items-center justify-center p-4 border rounded-lg shadow-sm",
      "hover:bg-gray-50 hover:shadow-md transition-all duration-150",
      "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
    )}
  >
    <Icon className="w-8 h-8 mb-2 text-gray-600" />
    <span className="text-sm font-medium text-gray-700 text-center">{label}</span>
  </button>
);

function PaymentDialog({ isOpen, setIsOpen, milestone, onConfirmPayment }) { // Removed projectName, added onConfirmPayment
  if (!milestone) return null;

  // Simulate selecting a payment method and confirming
  const handlePaymentMethodSelection = () => {
    // In a real scenario, you might set the selected method here
    // For simulation, we just proceed to confirmation
    if (onConfirmPayment) {
        onConfirmPayment(); // Call the confirmation callback passed from parent
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-lg bg-gray-50"> {/* Adjusted background */}
        <DialogHeader className="bg-white p-4 rounded-t-lg border-b"> {/* Header styling */}
          <DialogTitle className="text-center text-lg font-semibold text-gray-800">Estás pagando en Pagobra</DialogTitle>
          {/* Optional: Add Webpay-like logo or branding here */}
        </DialogHeader>

        <div className="p-6 space-y-6">
          {/* Amount Display */}
          <div className="flex justify-between items-center text-gray-700">
            <span className="text-sm">Monto a pagar ({milestone.name}):</span>
            <span className="text-2xl font-bold text-primary">${milestone.cost.toLocaleString('es-CL')}</span>
          </div>

          {/* Payment Method Selection */}
          <div>
            <h3 className="text-sm font-medium text-gray-600 mb-3 text-center">Selecciona tu medio de pago</h3>
            <div className="grid grid-cols-2 gap-4">
              <PaymentOption icon={Landmark} label="Débito" onClick={handlePaymentMethodSelection} />
              <PaymentOption icon={CreditCard} label="Crédito" onClick={handlePaymentMethodSelection} />
              <PaymentOption icon={Smartphone} label="Onepay y otras billeteras" onClick={handlePaymentMethodSelection} />
              <PaymentOption icon={Wallet} label="Prepago" onClick={handlePaymentMethodSelection} />
            </div>
          </div>

          {/* Security Note */}
          <p className="text-xs text-center text-gray-500 pt-2">
            Esta transacción se está realizando bajo un sistema seguro (simulado).
          </p>
        </div>

        {/* Dialog Footer */}
        <DialogFooter className="bg-white p-4 rounded-b-lg border-t flex justify-between">
           <Button variant="ghost" className="text-primary hover:bg-blue-50" onClick={() => setIsOpen(false)}>
             &lt; Anular compra y volver
           </Button>
           {/* The confirmation is now handled by clicking a payment method */}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default PaymentDialog;
  