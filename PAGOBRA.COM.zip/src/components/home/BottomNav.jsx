
import React from 'react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Home, MessageSquare } from 'lucide-react'; // Removed FolderKanban

function BottomNav({ activeTab, setActiveTab, activeChatId, setActiveChatId }) {
  return (
    <div className={`fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50 ${activeChatId ? 'hidden sm:block' : ''}`}>
      <Tabs value={activeTab} onValueChange={(value) => { setActiveTab(value); setActiveChatId(null); }} className="w-full">
        <TabsList className="grid w-full grid-cols-2 h-16 rounded-none"> {/* Changed grid-cols-3 to grid-cols-2 */}
          <TabsTrigger value="inicio" className="flex flex-col items-center justify-center h-full data-[state=active]:bg-blue-100 data-[state=active]:text-primary rounded-none text-gray-600">
            <Home className="h-5 w-5 mb-1" />
            <span className="text-xs">Inicio</span>
          </TabsTrigger>
          {/* Removed Projects TabTrigger */}
          <TabsTrigger value="chat" className="flex flex-col items-center justify-center h-full data-[state=active]:bg-blue-100 data-[state=active]:text-primary rounded-none text-gray-600">
            <MessageSquare className="h-5 w-5 mb-1" />
            <span className="text-xs">Chat</span>
          </TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  );
}

export default BottomNav;
  