
import React from 'react';
import { Button } from '@/components/ui/button';
import { CheckCircle, Circle, MapPin, Construction, Sparkles, Flag, Wrench, Image as ImageIcon, Edit2, Home as HomeIcon, Zap, Droplet, DollarSign } from 'lucide-react'; // Changed Camera to ImageIcon
import { calculateMilestoneProgress, getMilestoneStatusText } from '@/lib/projectUtils';
import { cn } from '@/lib/utils';
import MilestoneDetailPopover from '@/components/owner/MilestoneDetailPopover';

// Mapping milestone names to icons
const milestoneIcons = {
  'Acuerdo': Flag,
  'Radier': Construction,
  'Estructura': HomeIcon,
  'Aislante': Sparkles,
  'Electricidad y gasfiteria': Zap,
  'Forrado externo': Construction,
  'Forrado interior': Construction,
  'Terminaciones finas': Sparkles,
  'default': MapPin
};

const getMilestoneIcon = (milestoneName) => {
  return milestoneIcons[milestoneName] || milestoneIcons['default'];
};

function MilestoneItem({
  milestone,
  overallProgress,
  milestoneDetails,
  isPayableNow,
  // Removed isSelected, onCheckboxChange, isCheckboxInteractive
  showPaymentFeatures,
  onPhotoClick,
  onProgressClick,
  onPayClick, // Added handler for pay button
  isPhotoClickable,
  isProgressClickable,
  userType,
  isLast,
  isDetailPopoverOpen,
  onOpenDetailPopover,
  onCloseDetailPopover,
}) {
  const milestoneProgress = calculateMilestoneProgress(milestone, overallProgress);
  const isCompleted = milestoneProgress === 100;
  const isPaid = milestoneDetails?.paid > 0;
  const isInProgressOrPaid = isPaid || (milestoneProgress > 0 && milestoneProgress < 100); // Combine paid and in progress for orange color

  const IconComponent = getMilestoneIcon(milestone.name);
  const description = getMilestoneStatusText(milestone, milestoneProgress, milestoneDetails);

  // Updated Color Logic
  const iconBgColor = isCompleted ? 'bg-green-500' : isInProgressOrPaid ? 'bg-orange-500' : 'bg-gray-400';
  const textColor = isCompleted ? 'text-green-600' : isInProgressOrPaid ? 'text-orange-600' : 'text-gray-500';
  const descriptionColor = isCompleted ? 'text-gray-500' : isInProgressOrPaid ? 'text-gray-600' : 'text-gray-400';

  const handleIconClick = (e) => {
      e.stopPropagation();
      if (onOpenDetailPopover) {
          onOpenDetailPopover(milestone.name);
      }
  };

  const handlePayButtonClick = (e) => {
      e.stopPropagation();
      if (onPayClick) {
          onPayClick(milestone); // Pass the full milestone object
      }
  };

  return (
    <div className="relative flex items-start pl-10 sm:pl-12 pb-6 last:pb-0">
      {/* Icon and Vertical Line - Wrapped in Popover */}
      <MilestoneDetailPopover
         milestone={milestone}
         milestoneDetails={milestoneDetails}
         overallProgress={overallProgress}
         isOpen={isDetailPopoverOpen}
         onOpenChange={(open) => open ? onOpenDetailPopover(milestone.name) : onCloseDetailPopover()}
         trigger={
            <div
                className="absolute left-0 top-0 flex flex-col items-center cursor-pointer group"
                onClick={handleIconClick}
                aria-label={`Ver detalles de ${milestone.name}`}
            >
                <div className={cn(
                    "flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-full z-10 transition-transform duration-150 group-hover:scale-110",
                    iconBgColor
                )}>
                <IconComponent className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
            </div>
         }
      />

      {/* Milestone Content */}
      <div className="flex-grow flex justify-between items-start ml-3 sm:ml-4">
         <div className="flex-1 mr-2">
             <h5 className={cn("font-semibold", textColor)}>{milestone.name}</h5>
             {/* Conditional Description or Payment Info */}
             {showPaymentFeatures && isPayableNow ? (
                 <div className="flex items-center space-x-2 mt-1">
                     <span className="text-sm font-medium text-orange-600 flex items-center">
                         <DollarSign className="w-3.5 h-3.5 mr-1" /> Pago: ${milestone.cost.toLocaleString('es-CL')}
                     </span>
                     <Button
                        size="sm"
                        variant="default"
                        className="h-7 px-2 py-1 text-xs bg-orange-500 hover:bg-orange-600"
                        onClick={handlePayButtonClick}
                     >
                         Pagar
                     </Button>
                 </div>
             ) : (
                 <p className={cn("text-sm mt-0.5", descriptionColor)}>{description}</p>
             )}
         </div>

         {/* Actions */}
         <div className="flex items-center space-x-1 flex-shrink-0">
             {/* Photo Button */}
             {isPhotoClickable && (
                <button
                  onClick={onPhotoClick}
                  className={cn(
                      "p-1 rounded-full transition-colors duration-150",
                      (milestoneDetails.images && milestoneDetails.images.length > 0)
                          ? "text-blue-500 hover:bg-blue-100"
                          : "text-gray-400 hover:bg-gray-100"
                  )}
                  title={(milestoneDetails.images && milestoneDetails.images.length > 0) ? "Ver Fotos" : (userType === 'constructor' ? "Añadir Fotos" : "Sin Fotos")}
                  aria-label={userType === 'constructor' ? "Administrar Fotos" : "Ver Fotos"}
                 >
                  <ImageIcon className="w-4 h-4 sm:w-5 sm:h-5" /> {/* Changed Icon */}
                </button>
             )}

             {/* Progress Update Button (Constructor) */}
             {isProgressClickable && (
                <button
                  onClick={onProgressClick}
                  className="p-1 rounded-full text-gray-400 hover:bg-gray-100 hover:text-gray-600 transition-colors duration-150"
                  title="Actualizar Progreso"
                  aria-label="Actualizar Progreso"
                >
                  <Edit2 className="w-4 h-4 sm:w-5 sm:h-5" />
                </button>
             )}

             {/* Removed Checkbox */}
         </div>
      </div>
    </div>
  );
}

export default MilestoneItem;
  