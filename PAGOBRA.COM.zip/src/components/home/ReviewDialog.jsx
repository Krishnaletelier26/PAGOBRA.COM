
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Star } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

const renderStars = (interactive = false, currentRating = 0, setRating = () => {}) => {
  return (
    <div className={`flex ${interactive ? 'cursor-pointer' : ''} text-yellow-400`}>
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={`w-5 h-5 ${interactive ? 'hover:text-yellow-500' : ''}`}
          fill={i < (interactive ? currentRating : 0) ? 'currentColor' : 'none'}
          onClick={() => interactive && setRating(i + 1)}
        />
      ))}
    </div>
  );
};

function ReviewDialog({ project, isOpen, setIsOpen }) {
  const [reviewText, setReviewText] = useState('');
  const [reviewRating, setReviewRating] = useState(0);
  const { toast } = useToast();

  const handleSubmitReview = (projectId) => {
     if (reviewText.trim() === '' || reviewRating === 0) {
       toast({
         title: "Error",
         description: "Por favor, escribe una reseña y selecciona una calificación.",
         variant: "destructive",
       });
       return;
     }
    // Simulación: Enviar reseña
    console.log(`Submitting review for project ${projectId}: Rating ${reviewRating}, Text: ${reviewText}`);
    toast({
      title: "Reseña Enviada",
      description: "Gracias por tus comentarios.",
    });
    setReviewText('');
    setReviewRating(0);
    setIsOpen(false); // Close the dialog on successful submission
  };

  // Reset state when dialog opens or project changes
  React.useEffect(() => {
    if (isOpen) {
      setReviewText('');
      setReviewRating(0);
    }
  }, [isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Escribir Reseña para {project?.name}</DialogTitle>
          <DialogDescription>
            Comparte tu experiencia con {project?.builder}.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="flex items-center justify-center space-x-1">
            <span className="mr-2 text-sm font-medium">Calificación:</span>
            {renderStars(true, reviewRating, setReviewRating)}
          </div>
          <Textarea
            placeholder="Escribe tu reseña aquí..."
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            className="min-h-[100px]"
          />
        </div>
        <DialogFooter>
           <DialogClose asChild>
            <Button type="button" variant="secondary">Cancelar</Button>
          </DialogClose>
          {/* DialogClose removed from submit button to prevent closing on validation error */}
          <Button type="button" onClick={() => handleSubmitReview(project.id)} className="bg-blue-600 hover:bg-blue-700">Enviar Reseña</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default ReviewDialog;
