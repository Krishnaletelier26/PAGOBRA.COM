
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import MilestoneListDisplay from '@/components/shared/MilestoneListDisplay';
import PaymentDialog from '@/components/home/PaymentDialog';
import MilestonePhotoViewDialog from '@/components/owner/MilestonePhotoViewDialog';
import ProjectInfoDisplay from '@/components/shared/ProjectInfoDisplay'; // Refactored component
import PaymentActionArea from '@/components/shared/PaymentActionArea'; // Refactored component
import { findNextActionableMilestone, projectMilestonesData } from '@/lib/projectUtils';
import { useToast } from '@/components/ui/use-toast';
import { initializeMilestonesStatus } from '@/lib/storageUtils'; // Use central initializer

function ProjectDetailsDialog({ project, isOpen, setIsOpen, onUpdateProject }) {
  const [selectedMilestoneToPay, setSelectedMilestoneToPay] = useState(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isPhotoViewModalOpen, setIsPhotoViewModalOpen] = useState(false);
  const [selectedMilestoneForView, setSelectedMilestoneForView] = useState(null);
  const [milestoneImages, setMilestoneImages] = useState([]);

  const { toast } = useToast();

  if (!project) return null;

  // Ensure milestones data exists using the utility function
  const milestonesStatus = project.milestones || initializeMilestonesStatus();
  // Ensure sub-properties exist (belt and suspenders)
   Object.values(milestonesStatus).forEach(status => {
        if (!Array.isArray(status.images)) {
            status.images = [];
        }
        if (typeof status.paid === 'undefined') {
             status.paid = 0;
        }
    });

  const nextPayableMilestone = findNextActionableMilestone(project.progress, milestonesStatus);

  const handleCheckboxChange = (checked, milestoneName) => {
    if (checked && nextPayableMilestone && milestoneName === nextPayableMilestone.name) {
      setSelectedMilestoneToPay(nextPayableMilestone);
    } else {
      setSelectedMilestoneToPay(null);
    }
  };

  const handleOpenPaymentModal = () => {
    if (selectedMilestoneToPay) {
      setIsPaymentModalOpen(true);
    } else {
      toast({
        title: "Selección Requerida",
        description: "Por favor, selecciona el próximo hito a pagar.",
        variant: "destructive",
      });
    }
  };

  const handlePaymentSuccess = (paidMilestoneName) => {
    const updatedMilestones = {
      ...milestonesStatus, // Use the validated status object
      [paidMilestoneName]: { ...(milestonesStatus[paidMilestoneName] || { images: [] }), paid: 1 }
    };
    onUpdateProject(project.id, { milestones: updatedMilestones });
    setSelectedMilestoneToPay(null);
    setIsPaymentModalOpen(false);
    toast({ title: "Pago Exitoso", description: `Pago para ${paidMilestoneName} procesado.`, variant: "success" });

     // Simulate progress increase
     setTimeout(() => {
        const milestoneIndex = projectMilestonesData.findIndex(m => m.name === paidMilestoneName);
        if (milestoneIndex !== -1) {
            const nextProgress = projectMilestonesData[milestoneIndex].range[0];
            onUpdateProject(project.id, { progress: Math.min(nextProgress, 100) });
        }
     }, 1500);
  };

  const handleMilestonePhotoClick = (milestoneName, images) => {
    const validImages = Array.isArray(images) ? images : [];
    if (validImages.length > 0) {
        setSelectedMilestoneForView(milestoneName);
        setMilestoneImages(validImages);
        setIsPhotoViewModalOpen(true);
    } else {
         toast({ title: "Sin Fotos", description: `No hay fotos disponibles para ${milestoneName}.`, variant: "default" });
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-primary">{project.name}</DialogTitle>
            <DialogDescription>
              Seguimiento de tu proyecto con {project.builderName}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            {/* Project Info */}
            <ProjectInfoDisplay project={project} />

            {/* Overall Progress Bar */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium text-gray-700">Progreso General:</span>
                <span className="text-sm font-bold text-primary">{project.progress}%</span>
              </div>
              <Progress value={project.progress} className="h-2 rounded-full" />
            </div>

            {/* Milestone List */}
            <MilestoneListDisplay
              overallProgress={project.progress}
              milestonesStatus={milestonesStatus}
              showPaymentFeatures={true}
              selectedMilestoneName={selectedMilestoneToPay?.name}
              onCheckboxChange={handleCheckboxChange}
              onMilestonePhotoClick={handleMilestonePhotoClick}
              userType="owner"
            />

             <p className="text-xs text-center text-gray-400 pt-2">
                Haz clic en un hito para ver fotos de progreso (si están disponibles).
             </p>

            {/* Payment Action Area */}
            <PaymentActionArea
                nextPayableMilestone={nextPayableMilestone}
                selectedMilestoneToPay={selectedMilestoneToPay}
                onOpenPaymentModal={handleOpenPaymentModal}
                projectProgress={project.progress}
            />
          </div>
          <DialogFooter className="mt-4">
            <DialogClose asChild>
              <Button variant="outline">Cerrar</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payment Modal */}
      {selectedMilestoneToPay && (
        <PaymentDialog
          isOpen={isPaymentModalOpen}
          setIsOpen={setIsPaymentModalOpen}
          milestone={selectedMilestoneToPay}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

       {/* Photo View Modal */}
      {selectedMilestoneForView && (
        <MilestonePhotoViewDialog
          isOpen={isPhotoViewModalOpen}
          setIsOpen={setIsPhotoViewModalOpen}
          milestoneName={selectedMilestoneForView}
          images={milestoneImages}
        />
      )}
    </>
  );
}

export default ProjectDetailsDialog;
  