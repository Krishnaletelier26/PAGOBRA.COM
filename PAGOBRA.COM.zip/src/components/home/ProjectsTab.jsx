
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Star, CheckCircle, Clock, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import ReviewDialog from '@/components/home/ReviewDialog';
import ProjectDetailsDialog from '@/components/home/ProjectDetailsDialog';

// Datos ficticios (pueden venir como props)
const mockPendingProjects = [
  { id: 'P001', name: 'Casa Modelo Sol', builder: 'Constructora Alfa', progress: 75, nextMilestoneToPay: null, milestones: { 'Acuerdo': 100, 'Radier': 100, 'Estructura': 100, 'Aislante': 100, 'Electricidad y gasfiteria': 100, 'Forrado externo': 50, 'Forrado interior': 0, 'Terminaciones finas': 0 } }, // Example with milestones
  { id: 'P002', name: 'Cabaña Bosque', builder: 'Edificaciones Beta', progress: 25, nextMilestoneToPay: 'Estructura', milestones: { 'Acuerdo': 100, 'Radier': 100, 'Estructura': 0, 'Aislante': 0, 'Electricidad y gasfiteria': 0, 'Forrado externo': 0, 'Forrado interior': 0, 'Terminaciones finas': 0 } }, // Example needing payment for Estructura
  { id: 'P003', name: 'Loft Urbano', builder: 'Proyectos Gamma', progress: 0, nextMilestoneToPay: 'Acuerdo', milestones: {} }, // New project needing initial payment
];

const mockCompletedProjects = [
  { id: 'C001', name: 'Residencia Luna', builder: 'Proyectos Gamma', completionDate: '2024-12-15', image: 'Finished modern residence at night' },
];

function ProjectsTab() {
  const [activeProjectTab, setActiveProjectTab] = useState('pendientes');
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false);
  const [selectedProjectForReview, setSelectedProjectForReview] = useState(null);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [selectedProjectForDetails, setSelectedProjectForDetails] = useState(null);
  // Added state to manage pending projects data, including payment status
  const [pendingProjects, setPendingProjects] = useState(mockPendingProjects);

  const openReviewDialog = (project) => {
    setSelectedProjectForReview(project);
    setIsReviewDialogOpen(true);
  };

  const openDetailsDialog = (project) => {
    // Pass the current project data, including milestone details
    const projectWithDetails = pendingProjects.find(p => p.id === project.id) || project;
    setSelectedProjectForDetails(projectWithDetails);
    setIsDetailsDialogOpen(true);
  };

  // Function to update project state after simulated payment
  const handlePaymentSuccess = (projectId, paidMilestoneName) => {
    setPendingProjects(prevProjects =>
      prevProjects.map(p => {
        if (p.id === projectId) {
          // Find the next milestone that might need payment
          const milestoneNames = ['Acuerdo', 'Radier', 'Estructura', 'Aislante', 'Electricidad y gasfiteria', 'Forrado externo', 'Forrado interior', 'Terminaciones finas'];
          const currentMilestoneIndex = milestoneNames.indexOf(paidMilestoneName);
          let nextMilestone = null;
          if (currentMilestoneIndex < milestoneNames.length - 1) {
             // Simplified: Assume next milestone needs payment immediately after current one is paid.
             // A real app might have different logic based on progress.
             nextMilestone = milestoneNames[currentMilestoneIndex + 1];
          }

          return {
            ...p,
            nextMilestoneToPay: nextMilestone, // Update or clear the next payment requirement
             // Optionally, update progress slightly to reflect start of the paid milestone
             // progress: updatedProgressValue,
            milestones: {
              ...p.milestones,
              [paidMilestoneName]: p.milestones?.[paidMilestoneName] > 0 ? p.milestones[paidMilestoneName] : 1 // Mark as started if not already
            }
          };
        }
        return p;
      })
    );
    // Optionally refetch details if they were dependent on payment status
    // This requires passing the update function down or using context/global state
     setSelectedProjectForDetails(prev => prev ? {...prev, nextMilestoneToPay: null} : null); // Basic update for the currently open dialog
  };


  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-0">
      <h2 className="text-xl sm:text-2xl font-semibold text-primary mb-4 px-4 sm:px-6">Mis Proyectos</h2>
      <Tabs value={activeProjectTab} onValueChange={setActiveProjectTab} className="w-full">
         <div className="sticky top-16 z-20 bg-white/90 backdrop-blur-sm px-4 sm:px-6 py-2 border-b">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="pendientes" className="data-[state=active]:bg-blue-100 data-[state=active]:text-primary">
                <Clock className="w-4 h-4 mr-2"/> Pendientes
              </TabsTrigger>
              <TabsTrigger value="completadas" className="data-[state=active]:bg-blue-100 data-[state=active]:text-primary">
                <CheckCircle className="w-4 h-4 mr-2"/> Completadas
              </TabsTrigger>
            </TabsList>
         </div>

        <TabsContent value="pendientes" className="mt-4 px-4 sm:px-6">
          <div className="space-y-4">
            {pendingProjects.map(project => (
              <Card key={project.id} className="overflow-hidden shadow-md border border-blue-100">
                <CardHeader className="p-4 bg-blue-50/50">
                  <CardTitle className="text-lg text-blue-800">{project.name}</CardTitle>
                  <CardDescription>{project.builder}</CardDescription>
                  {project.nextMilestoneToPay && (
                    <CardDescription className="text-orange-600 font-medium pt-1">
                       Requiere pago para: {project.nextMilestoneToPay}
                    </CardDescription>
                   )}
                </CardHeader>
                <CardContent className="p-4 space-y-3">
                   <img
                      className="w-full h-40 object-cover rounded"
                      alt={`Imagen ${project.name}`}
                      src={`https://images.unsplash.com/photo-1586880244386-8b3e34c8382c?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=${project.id}`} /> {/* Slightly varying image */}
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-medium text-gray-600">Progreso:</span>
                      <span className="text-sm font-bold text-primary">{project.progress}%</span>
                    </div>
                    <Progress value={project.progress} className="h-2" />
                  </div>
                   <Button variant="outline" size="sm" className="w-full" onClick={() => openDetailsDialog(project)}>
                     <Eye className="w-4 h-4 mr-2" /> Ver Detalles {project.nextMilestoneToPay ? '(Pago Pendiente)' : ''}
                   </Button>
                </CardContent>
              </Card>
            ))}
             {pendingProjects.length === 0 && <p className="text-center text-gray-500 py-8">No tienes proyectos pendientes.</p>}
          </div>
        </TabsContent>
        <TabsContent value="completadas" className="mt-4 px-4 sm:px-6">
           <div className="space-y-4">
            {mockCompletedProjects.map(project => (
              <Card key={project.id} className="overflow-hidden shadow-md border border-green-100">
                 <CardHeader className="p-4 bg-green-50/50">
                  <CardTitle className="text-lg text-green-800">{project.name}</CardTitle>
                   {/* Changed date format */}
                  <CardDescription>{project.builder} (Completado: {new Date(project.completionDate).toLocaleDateString('es-CL', { dateStyle: 'short' })})</CardDescription>
                </CardHeader>
                 <CardContent className="p-4 space-y-3">
                   <img
                      className="w-full h-40 object-cover rounded"
                      alt={`Imagen ${project.name}`}
                      src={`https://images.unsplash.com/photo-1697256200022-f61abccad430?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=${project.id}`} /> {/* Slightly varying image */}

                  <Button variant="default" size="sm" className="w-full bg-blue-600 hover:bg-blue-700" onClick={() => openReviewDialog(project)}>
                    <Star className="w-4 h-4 mr-2"/> Escribir Reseña
                  </Button>

                </CardContent>
              </Card>
            ))}
             {mockCompletedProjects.length === 0 && <p className="text-center text-gray-500 py-8">No tienes proyectos completados.</p>}
          </div>
        </TabsContent>
      </Tabs>

      {selectedProjectForReview && (
        <ReviewDialog
          project={selectedProjectForReview}
          isOpen={isReviewDialogOpen}
          setIsOpen={setIsReviewDialogOpen}
        />
      )}

      {selectedProjectForDetails && (
        <ProjectDetailsDialog
          project={selectedProjectForDetails}
          isOpen={isDetailsDialogOpen}
          setIsOpen={setIsDetailsDialogOpen}
          onPaymentSuccess={handlePaymentSuccess} // Pass the handler down
        />
      )}
    </motion.div>
  );
}

export default ProjectsTab;
