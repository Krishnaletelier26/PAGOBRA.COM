
import React from 'react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Settings, User, LogOut, Bell, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from "@/components/ui/use-toast";

// Accept userType, hasNotification, notificationData, and onNotificationClick props
function TopNav({ onProfileClick, userType, hasNotification, notificationData, onNotificationClick }) {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogout = () => {
    localStorage.removeItem('userType'); // Clear user type on logout
    navigate('/login');
  };

  const handleNotificationsClick = () => {
    if (!hasNotification || !notificationData) {
       toast({
         title: "Notificaciones",
         description: "No tienes notificaciones nuevas.",
         duration: 3000,
       });
       return;
    }

    // Owner specific logic: Open proposal review dialog if handler is provided
    if (userType === 'propietario' && notificationData.status === 'pending' && onNotificationClick) {
        onNotificationClick(notificationData); // Pass the proposal data to the handler
        // Optionally show a toast as well, or let the dialog be the main feedback
        // toast({
        //    title: "Nueva Propuesta Recibida",
        //    description: `De ${notificationData.builderName}. Haz clic para revisar.`,
        //    duration: 5000,
        // });
    }
    // Owner specific logic: Show toast if proposal was already actioned
    else if (userType === 'propietario' && notificationData.status !== 'pending') {
         toast({
           title: "Notificación Vista",
           description: `Ya has ${notificationData.status === 'accepted' ? 'aceptado' : 'rechazado'} la propuesta de ${notificationData.builderName}.`,
           duration: 5000,
         });
    }
     // Constructor specific logic: Show acceptance toast
    else if (userType === 'constructora' && notificationData.type === 'acceptance') {
      toast({
        title: "¡Propuesta Aceptada!",
        description: `${notificationData.clientName} ha aceptado tu propuesta para ${notificationData.projectName}.`,
        variant: "default",
        duration: 900000, // Keep toast visible longer
      });
    } else {
       // Fallback for other notifications or unknown states
       toast({
         title: "Nueva Notificación",
         description: "Tienes una nueva notificación.",
         duration: 5000,
       });
    }

    // Don't clear the visual indicator here to make it persistent
  };

  return (
    <div className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 bg-white border-b shadow-sm">
      <h1 className="text-xl font-semibold text-primary">Pagobra</h1>
      <div className="flex items-center space-x-2">
        {/* Notifications Button with Indicator */}
        <Button variant="ghost" size="icon" onClick={handleNotificationsClick} className="relative" disabled={!hasNotification && !onNotificationClick} aria-label="Notificaciones">
           <Bell className="h-5 w-5 text-gray-600" />
           {/* Red dot indicator */}
           {hasNotification && (
             <span className="absolute top-1 right-1 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />
           )}
        </Button>
        {/* Settings Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="Configuración">
              <Settings className="h-5 w-5 text-gray-600" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Mi Cuenta ({userType === 'propietario' ? 'Propietario' : 'Constructora'})</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onProfileClick} className="cursor-pointer">
              <User className="mr-2 h-4 w-4" />
              <span>Perfil</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-red-600 focus:text-red-700 focus:bg-red-50">
              <LogOut className="mr-2 h-4 w-4" />
              <span>Cerrar Sesión</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

export default TopNav;
  