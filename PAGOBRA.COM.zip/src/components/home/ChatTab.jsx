
import React from 'react';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Search } from 'lucide-react';
import { motion } from 'framer-motion';

// REMOVED default mockChats - Now passed as a prop

function ChatTab({ chatSearchTerm, setChatSearchTerm, setActiveChatId, mockChats = [] }) { // Added mockChats prop with default empty array

  const filteredChats = mockChats.filter(chat =>
    chat.name.toLowerCase().includes(chatSearchTerm.toLowerCase())
  );

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-0 sm:p-4">
      <h2 className="text-xl sm:text-2xl font-semibold text-primary mb-4 px-4 sm:px-0">Chats</h2>
      <div className="px-4 sm:px-0 mb-4 sticky top-16 sm:top-0 z-10 bg-white/80 backdrop-blur-sm py-2"> {/* Adjusted top position */}
         <div className="relative">
             <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
             <Input
                 type="text"
                 placeholder="Buscar chats..."
                 value={chatSearchTerm}
                 onChange={(e) => setChatSearchTerm(e.target.value)}
                 className="pl-10 w-full bg-white border-blue-200 rounded-full shadow-sm"
             />
         </div>
      </div>

      <div className="space-y-1 px-0">
         {filteredChats.map(chat => (
             <motion.div
                 key={chat.id}
                 initial={{ opacity: 0, x: -10 }}
                 animate={{ opacity: 1, x: 0 }}
                 transition={{ duration: 0.2 }}
                 onClick={() => setActiveChatId(chat.id)}
                 className="flex items-center p-3 hover:bg-blue-50 rounded-lg cursor-pointer mx-2 sm:mx-0"
             >
                 <Avatar className="h-10 w-10 mr-3">
                    {/* Use a generic avatar generation or a placeholder */}
                    <AvatarImage src={`https://avatar.vercel.sh/${chat.name.replace(/[^a-zA-Z0-9]/g, '')}.png`} alt={chat.name} />
                    <AvatarFallback>{chat.name?.substring(0, 1).toUpperCase() || '?'}</AvatarFallback>
                 </Avatar>
                 <div className="flex-grow overflow-hidden">
                     <p className="font-semibold truncate text-gray-800">{chat.name}</p>
                     <p className="text-sm text-gray-500 truncate">{chat.lastMessage}</p>
                 </div>
                 <div className="flex flex-col items-end ml-2 text-xs text-gray-400">
                     <span>{chat.time}</span>
                     {chat.unread > 0 && (
                         <span className="mt-1 bg-primary text-primary-foreground rounded-full px-1.5 py-0.5 text-[10px] font-bold">
                             {chat.unread}
                         </span>
                     )}
                 </div>
             </motion.div>
         ))}
          {filteredChats.length === 0 && <p className="text-center text-gray-500 py-8">No se encontraron chats.</p>}
      </div>
    </motion.div>
  );
}

export default ChatTab;
  