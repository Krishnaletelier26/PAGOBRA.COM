
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from "@/components/ui/use-toast";

// Mock user data (can be expanded or fetched based on userType)
const mockOwnerData = {
  name: 'Juan Pérez Cliente',
  email: 'juan.perez@email.com',
  phone: '+56 9 1234 5678',
};

const mockConstructorData = {
  name: 'Constructora XYZ Ltda.',
  email: 'contacto@constructoraxyz.cl',
  phone: '+56 2 9876 5432',
  contactPerson: 'Ana Martín', // Example extra field for constructor
};

// Accept userType prop
function ProfileDialog({ isOpen, setIsOpen, userType }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({});
  const { toast } = useToast();

  // Load appropriate mock data based on userType when dialog opens
  useEffect(() => {
    const initialData = userType === 'constructora' ? mockConstructorData : mockOwnerData;
    setFormData(initialData);
    setIsEditing(false); // Reset editing state
  }, [isOpen, userType]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSaveChanges = () => {
    // Simulate saving changes
    console.log(`Saving profile data for ${userType}:`, formData);
    // Update mock data (in real app, update backend)
    // This part needs refinement if you want mock data to persist across dialog opens
    // For now, it just logs and shows a toast
    toast({
      title: "Perfil Actualizado",
      description: "Tus datos han sido guardados (simulado).",
    });
    setIsEditing(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Mi Perfil ({userType === 'propietario' ? 'Propietario' : 'Constructora'})</DialogTitle>
          <DialogDescription>
            {isEditing ? "Edita tus datos." : "Visualiza tus datos."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {/* Common Fields */}
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              {userType === 'constructora' ? 'Empresa' : 'Nombre'}
            </Label>
            <Input
              id="name"
              value={formData.name || ''}
              onChange={handleInputChange}
              disabled={!isEditing}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="email" className="text-right">
              Correo
            </Label>
            <Input
              id="email"
              type="email"
              value={formData.email || ''}
              onChange={handleInputChange}
              disabled={!isEditing}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="phone" className="text-right">
              Teléfono
            </Label>
            <Input
              id="phone"
              value={formData.phone || ''}
              onChange={handleInputChange}
              disabled={!isEditing}
              className="col-span-3"
            />
          </div>

          {/* Constructor Specific Field */}
          {userType === 'constructora' && (
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="contactPerson" className="text-right">
                Contacto
              </Label>
              <Input
                id="contactPerson"
                value={formData.contactPerson || ''}
                onChange={handleInputChange}
                disabled={!isEditing}
                className="col-span-3"
              />
            </div>
          )}
        </div>
        <DialogFooter>
          {isEditing ? (
            <>
              <Button variant="outline" onClick={() => {
                 setIsEditing(false);
                 // Reset form data to initial state for the current user type
                 const initialData = userType === 'constructora' ? mockConstructorData : mockOwnerData;
                 setFormData(initialData);
              }}>Cancelar</Button>
              <Button onClick={handleSaveChanges} className="bg-blue-600 hover:bg-blue-700">Guardar Cambios</Button>
            </>
          ) : (
            <>
              <DialogClose asChild>
                <Button variant="secondary">Cerrar</Button>
              </DialogClose>
              <Button onClick={() => setIsEditing(true)} className="bg-blue-600 hover:bg-blue-700">Editar Perfil</Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default ProfileDialog;
  