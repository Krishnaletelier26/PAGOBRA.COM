
import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ArrowLeft, Send, Paperclip } from 'lucide-react';
import { motion } from 'framer-motion';
import { ScrollArea } from '@/components/ui/scroll-area'; // Import ScrollArea

// Mock Messages (replace with actual data fetching/state)
const mockMessages = {
    chat_proj_test_1: [
        { id: 'm1', sender: 'other', text: 'Hola, ¿cómo va el avance del radier?', time: '10:25' },
        { id: 'm2', sender: 'me', text: '¡Hola! Va bien, te mando fotos pronto.', time: '10:28' },
        { id: 'm3', sender: 'other', text: '¡Claro! Lo revisamos mañana.', time: '10:30' },
    ],
    support_1: [
         { id: 's1', sender: 'other', text: 'Bienvenido al soporte de Pagobra. ¿En qué podemos ayudarte?', time: 'Ayer' },
    ],
    // Add more mocks for constructor chats if needed
};

function ChatView({ chatId, chatName, onBack }) { // Added chatName prop
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const scrollAreaRef = useRef(null); // Ref for ScrollArea viewport

  useEffect(() => {
    // Load messages for the current chat ID
    setMessages(mockMessages[chatId] || []);
    // Reset input field
    setNewMessage('');
  }, [chatId]);

  // Scroll to bottom when messages change
  useEffect(() => {
      if (scrollAreaRef.current) {
          // Access the DOM node using the ref
          const viewport = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
          if (viewport) {
              viewport.scrollTop = viewport.scrollHeight;
          }
      }
  }, [messages]);

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (newMessage.trim() === '') return;

    const newMsg = {
      id: `msg_${Date.now()}`,
      sender: 'me',
      text: newMessage,
      time: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, newMsg]);
    setNewMessage('');

     // Simulate reply (optional)
     setTimeout(() => {
         const replyMsg = {
             id: `msg_${Date.now() + 1}`,
             sender: 'other',
             text: 'Recibido, gracias!',
             time: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }),
         };
         setMessages(prev => [...prev, replyMsg]);
     }, 1500);

  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="flex items-center p-3 sm:p-4 border-b bg-white shadow-sm sticky top-0 z-10">
        <Button variant="ghost" size="icon" className="mr-2" onClick={onBack}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <Avatar className="h-9 w-9 mr-3">
           <AvatarImage src={`https://avatar.vercel.sh/${chatName?.replace(/[^a-zA-Z0-9]/g, '')}.png`} alt={chatName} />
           <AvatarFallback>{chatName?.substring(0, 1).toUpperCase() || '?'}</AvatarFallback>
        </Avatar>
        <span className="font-semibold text-gray-800 truncate">{chatName}</span>
        {/* Add more actions like call/video if needed */}
      </div>

      {/* Messages Area */}
      <ScrollArea className="flex-grow p-4" ref={scrollAreaRef}>
        <div className="space-y-4">
          {messages.map(msg => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[70%] p-2.5 rounded-lg ${msg.sender === 'me' ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-white text-gray-800 border border-gray-200 rounded-bl-none shadow-sm'}`}>
                <p className="text-sm">{msg.text}</p>
                <span className={`text-xs mt-1 block ${msg.sender === 'me' ? 'text-blue-100 opacity-80 text-right' : 'text-gray-400 text-right'}`}>
                  {msg.time}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="p-3 sm:p-4 border-t bg-white sticky bottom-16 sm:bottom-0 z-10"> {/* Adjusted bottom */}
        <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
          <Button type="button" variant="ghost" size="icon" className="text-gray-500">
             <Paperclip className="w-5 h-5" />
          </Button>
          <Input
            type="text"
            placeholder="Escribe un mensaje..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="flex-grow rounded-full bg-gray-100 border-gray-300 focus:border-primary focus:ring-primary"
            autoComplete="off"
          />
          <Button type="submit" size="icon" className="rounded-full bg-primary hover:bg-primary/90">
            <Send className="h-5 w-5 text-white" />
          </Button>
        </form>
      </div>
    </div>
  );
}

export default ChatView;
  