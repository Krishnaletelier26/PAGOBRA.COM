
import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Star } from 'lucide-react';

function CompletedProjectCard({ project, onViewReview }) {
  return (
    <Card className="w-full flex items-center p-3 border border-gray-200 rounded-lg hover:shadow-sm transition-shadow duration-200 bg-white">
       <img
          className="w-12 h-12 sm:w-16 sm:h-16 object-cover rounded-md mr-3 sm:mr-4 flex-shrink-0 border"
          alt={`Proyecto ${project.modelName || project.name}`}
          src={project.imageUrl || "https://images.unsplash.com/photo-1518791841217-8f162f1e1131"} />
        <div className="flex-grow text-sm overflow-hidden">
            <p className="font-semibold text-gray-900 truncate">
              {project.client}
            </p>
            <p className="text-sm text-gray-600 mt-1 truncate">
               Modelo: {project.modelName || 'N/A'}
            </p>
           <div className="flex items-center mt-1.5 text-green-600">
              <CheckCircle className="w-3.5 h-3.5 mr-1.5 flex-shrink-0"/>
              <span className="text-xs font-medium">Completado</span>
           </div>
        </div>
       <div className="ml-auto text-right flex-shrink-0 pl-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => onViewReview(project)}
              className="text-xs px-2 py-1 h-auto text-yellow-600 border-yellow-400 hover:bg-yellow-50 hover:text-yellow-700"
            >
             <Star className="w-3.5 h-3.5 mr-1" /> Ver Reseña
           </Button>
       </div>
    </Card>
  );
}

export default CompletedProjectCard;
  