
import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Clock, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

// Helper to format price
const formatPrice = (price) => {
    return price ? `$${price.toLocaleString('es-CL')}` : 'Precio no disponible';
};

// Helper to get status info
const getStatusInfo = (status) => {
    switch (status) {
      case 'proposal_sent':
        return { text: 'Esperando Aceptación', icon: Clock, variant: 'outline', disabled: true };
      case 'accepted':
        return { text: 'Propuesta Aceptada', icon: CheckCircle, variant: 'success', disabled: true };
      case 'rejected':
         return { text: 'Propuesta Rechazada', icon: CheckCircle, variant: 'destructive', disabled: true };
      case 'new':
      default:
        return { text: 'Propuesta', icon: FileText, variant: 'default', disabled: false };
    }
};

function VisitRequestCard({ request, onOpenProposalModal }) {
  const { text, icon: Icon, variant, disabled } = getStatusInfo(request.status);
  const action = request.status === 'new' ? () => onOpenProposalModal(request.id) : () => {};
  const price = request.houseModel?.basePrice;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="w-full flex items-center p-3 border border-gray-200 rounded-lg hover:shadow-sm transition-shadow duration-200 bg-white">
        <img
          className="w-12 h-12 sm:w-16 sm:h-16 object-cover rounded-md mr-3 sm:mr-4 flex-shrink-0 border"
          alt={`Modelo ${request.houseModel?.name || 'Desconocido'}`}
          src={request.houseModel?.imageUrl || "https://images.unsplash.com/photo-1568605114967-8130f3a36994"} />
        <div className="flex-grow text-sm overflow-hidden">
          <p className="font-semibold text-gray-900 truncate">
            {request.ownerName}
          </p>
          <p className="text-sm text-gray-600 mt-1 truncate">
             Modelo: {request.houseModel?.name || 'N/A'}
          </p>
          <p className="text-sm font-semibold text-primary mt-1">
            {formatPrice(price)}
          </p>
        </div>
        <div className="ml-auto text-right flex-shrink-0 pl-2">
          <Button
            size="sm"
            onClick={action}
            disabled={disabled}
            variant={variant}
            className="text-xs px-2 py-1 h-auto"
          >
            <Icon className="w-3.5 h-3.5 mr-1" />
            {text}
          </Button>
        </div>
      </Card>
    </motion.div>
  );
}

export default VisitRequestCard;
  