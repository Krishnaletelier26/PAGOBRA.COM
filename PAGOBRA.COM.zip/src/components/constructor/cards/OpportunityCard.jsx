
import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, User, Home, Hand } from 'lucide-react';
import { motion } from 'framer-motion';

function OpportunityCard({ opportunity, onApply }) {
  const { houseModel, ownerName, ownerAddress } = opportunity;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="w-full flex items-center p-3 border border-blue-100 rounded-lg hover:shadow-md transition-shadow duration-200 bg-gradient-to-r from-blue-50 via-white to-white">
        <img
          className="w-12 h-12 sm:w-16 sm:h-16 object-cover rounded-md mr-3 sm:mr-4 flex-shrink-0 border"
          alt={`Modelo ${houseModel?.name || 'Desconocido'}`}
          src={houseModel?.imageUrl || "https://images.unsplash.com/photo-1568605114967-8130f3a36994"} />

        <div className="flex-grow text-sm overflow-hidden mr-2">
          <p className="font-semibold text-primary truncate flex items-center">
             <Home className="w-3.5 h-3.5 mr-1.5 text-blue-600 flex-shrink-0" /> {houseModel?.name || 'N/A'}
          </p>
          <p className="text-gray-800 mt-1 truncate flex items-center">
             <User className="w-3.5 h-3.5 mr-1.5 text-gray-500 flex-shrink-0" /> {ownerName}
          </p>
           <p className="text-gray-600 mt-1 truncate flex items-center text-xs">
            <MapPin className="w-3.5 h-3.5 mr-1.5 text-gray-400 flex-shrink-0" /> {ownerAddress}
          </p>
        </div>

        <div className="ml-auto text-right flex-shrink-0 pl-1">
          <Button
            size="sm"
            onClick={onApply}
            variant="default"
            className="text-xs px-2 py-1 h-auto bg-blue-600 hover:bg-blue-700"
          >
            <Hand className="w-3.5 h-3.5 mr-1" />
            Aplicar
          </Button>
        </div>
      </Card>
    </motion.div>
  );
}

export default OpportunityCard;
  