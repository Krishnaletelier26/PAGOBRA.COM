
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Upload, Image as ImageIcon, X } from 'lucide-react';

function MilestonePhotoUploadDialog({ isOpen, setIsOpen, milestoneName, existingImages = [], onAddImage }) {
  const [isUploading, setIsUploading] = useState(false); // Simulate upload state

  const handleFileSelect = () => {
    // Simulate file selection and upload
    setIsUploading(true);
    // In a real app, you'd use a file input and upload service.
    // Here, we just add a placeholder URL after a short delay.
    setTimeout(() => {
      // Generate a placeholder image URL (using Unsplash keywords related to construction)
      const keywords = ['construction', 'building', 'site', 'progress', 'tools', 'concrete', 'frame'];
      const randomKeyword = keywords[Math.floor(Math.random() * keywords.length)];
      const placeholderUrl = `https://images.unsplash.com/photo-1518791841217-8f162f1e1131?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwxfDB8MXxyYW5kb218MHx8${randomKeyword}fHx8fHwxNzE0NTAwMDAw&ixlib=rb-4.0.3&q=80&w=400`; // Smaller width for thumbnail

      onAddImage(milestoneName, placeholderUrl);
      setIsUploading(false);
    }, 1500); // Simulate 1.5 second upload time
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <ImageIcon className="w-5 h-5 mr-2 text-primary" /> Fotos del Hito: {milestoneName}
          </DialogTitle>
          <DialogDescription>
            Sube fotos para mostrar el progreso de este hito.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-4">
          {/* Display Existing Images */}
          {existingImages.length > 0 && (
            <div>
              <h4 className="text-sm font-medium mb-2 text-gray-600">Fotos Actuales:</h4>
              <ScrollArea className="h-[150px] w-full rounded-md border p-2">
                <div className="grid grid-cols-3 gap-2">
                  {existingImages.map((imgUrl, index) => (
                    <div key={index} className="relative aspect-square">
                      <img 
                        className="object-cover w-full h-full rounded"
                        alt={`Progreso ${milestoneName} ${index + 1}`}
                       src="https://images.unsplash.com/photo-1578245106540-9079f6003657" />
                       {/* In a real app, you might add a delete button here */}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}

          {/* Simulated Upload Button */}
          <div>
             {/* Hidden file input for semantic correctness, though not used for simulation */}
             <Input id="photo-upload-input" type="file" className="hidden" accept="image/*" />
             <Button
                onClick={handleFileSelect}
                disabled={isUploading}
                className="w-full"
                variant="outline"
             >
                <Upload className={`w-4 h-4 mr-2 ${isUploading ? 'animate-spin' : ''}`} />
                {isUploading ? 'Subiendo...' : 'Subir Foto (Simulado)'}
             </Button>
             <p className="text-xs text-center text-gray-500 mt-1">
                Esto añadirá una foto de ejemplo.
             </p>
          </div>

        </div>
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cerrar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default MilestonePhotoUploadDialog;
  