
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Eye, User } from 'lucide-react'; // Removed MessageSquare, Star. Added User.
import ConstructorProjectDetailsDialog from '@/components/constructor/ConstructorProjectDetailsDialog';
// Removed ClientReviewDialog import as it's not used
import { motion } from 'framer-motion';

// Mock function to fetch constructor projects (replace with actual data fetching/state management)
const fetchConstructorProjects = () => {
  try {
    const saved = localStorage.getItem('pendingProjects'); // Reuse owner's projects for demo
    const parsed = JSON.parse(saved);
     // Add validation: ensure milestones have the 'images' property
      if (Array.isArray(parsed)) {
        parsed.forEach(proj => {
          if (!proj.imageUrl) { // Add placeholder image if missing
             proj.imageUrl = `https://images.unsplash.com/photo-1518791841217-8f162f1e1131?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwxfDB8MXxyYW5kb218MHx8YnVpbGRpbmdfcHJvZ3Jlc3N8fHx8fHwxNzE0NTAwMDAw&ixlib=rb-4.0.3&q=80&w=1080`;
          }
          if (proj.milestones) {
            Object.keys(proj.milestones).forEach(mName => {
              if (typeof proj.milestones[mName] !== 'object' || proj.milestones[mName] === null) {
                 proj.milestones[mName] = { paid: 0, images: [] }; // Initialize if malformed
              } else if (!Array.isArray(proj.milestones[mName].images)) {
                proj.milestones[mName].images = []; // Ensure images array exists
              }
            });
          } else {
             // Initialize milestones if missing (using a simplified structure for constructor if needed)
             proj.milestones = {}; // Or initialize properly if constructor updates them
          }
        });
        return parsed;
      }
    return []; // Fallback
  } catch (e) {
    console.error("Failed to load projects state for constructor:", e);
    return [];
  }
};

function ConstructorProjectsTab() {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  // Removed review modal state

  useEffect(() => {
    setProjects(fetchConstructorProjects());
  }, []);

   // Function to update project data (e.g., after adding a photo or updating progress)
  const handleUpdateProject = (projectId, updates) => {
    setProjects(prevProjects => {
      const updatedProjects = prevProjects.map(p =>
        p.id === projectId ? { ...p, ...updates } : p
      );
      // Persist updated projects back to localStorage
      try {
        localStorage.setItem('pendingProjects', JSON.stringify(updatedProjects));
      } catch (e) {
        console.error("Failed to save updated projects state:", e);
      }
      return updatedProjects;
    });

     // Also update the selected project if it's the one being modified
     if (selectedProject && selectedProject.id === projectId) {
        setSelectedProject(prev => ({ ...prev, ...updates }));
     }
  };


  const handleViewDetails = (project) => {
    setSelectedProject(project);
    setIsDetailsModalOpen(true);
  };

  // Removed handleViewReview and handleChat

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="p-4 sm:p-6 space-y-6"
    >
      <h1 className="text-2xl sm:text-3xl font-bold text-primary mb-4">Mis Proyectos</h1>

       {/* Tabs for Pending/Completed - Basic Structure */}
       <div className="flex space-x-2 border-b">
         <Button variant="ghost" className="text-primary font-semibold border-b-2 border-primary pb-1 px-3 h-auto">Pendientes</Button>
         <Button variant="ghost" className="text-gray-500 pb-1 px-3 h-auto">Completados</Button>
       </div>


      {projects.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {projects.map((project) => (
            <Card key={project.id} className="flex flex-col overflow-hidden hover:shadow-lg transition-shadow duration-300 rounded-lg border">
              <CardHeader className="pb-3">
                <CardTitle className="text-xl font-semibold text-primary">{project.modelName || project.name}</CardTitle>
                <CardDescription className="flex items-center text-sm text-gray-600 pt-1">
                  <User className="w-3.5 h-3.5 mr-1.5 flex-shrink-0" />
                  {project.client} - {project.address}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow px-6 pt-0 pb-4 space-y-3">
                 {/* Image Placeholder */}
                 <div className="aspect-video w-full bg-gray-100 rounded-md overflow-hidden">
                    <img 
                        className="w-full h-full object-cover"
                        alt={`Imagen proyecto ${project.modelName || project.name}`}
                     src="https://images.unsplash.com/photo-1616762073012-9ccb89774098" />
                 </div>

                {/* Progress Bar */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-gray-700">Progreso:</span>
                    <span className="text-sm font-bold text-primary">{project.progress}%</span>
                  </div>
                  <Progress value={project.progress} className="h-2 rounded-full" />
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50 p-4 border-t">
                 <Button className="w-full" variant="outline" size="sm" onClick={() => handleViewDetails(project)}>
                   <Eye className="w-4 h-4 mr-2" /> Ver detalles
                 </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-500 mt-12">No tienes proyectos pendientes.</p>
      )}

      {/* Details Modal */}
      {selectedProject && (
        <ConstructorProjectDetailsDialog
          project={selectedProject}
          isOpen={isDetailsModalOpen}
          setIsOpen={setIsDetailsModalOpen}
          onUpdateProject={handleUpdateProject} // Pass the update handler
        />
      )}
      {/* Review Modal Removed */}
    </motion.div>
  );
}

export default ConstructorProjectsTab;
  