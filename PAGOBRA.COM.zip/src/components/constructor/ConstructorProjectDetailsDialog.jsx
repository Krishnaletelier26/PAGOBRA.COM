
import React, { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Image as ImageIcon, Edit2, User, Home, Wallet, Calendar } from 'lucide-react'; // Use ImageIcon
import MilestoneListDisplay from '@/components/shared/MilestoneListDisplay';
import MilestonePhotoUploadDialog from '@/components/constructor/MilestonePhotoUploadDialog';
import MilestoneProgressUpdateDialog from '@/components/constructor/MilestoneProgressUpdateDialog';
// import ProjectInfoDisplay from '@/components/shared/ProjectInfoDisplay'; // Removed, info integrated directly
import { useToast } from '@/components/ui/use-toast';
import { projectMilestonesData } from '@/lib/projectUtils';
import { initializeMilestonesStatus } from '@/lib/storageUtils';
import { cn } from '@/lib/utils';

// Function to calculate total paid amount
const calculateTotalPaid = (milestonesStatus) => {
    let total = 0;
    projectMilestonesData.forEach(milestone => {
        if (milestonesStatus[milestone.name]?.paid > 0) {
            total += milestone.cost;
        }
    });
    return total;
};


function ConstructorProjectDetailsDialog({ project, isOpen, setIsOpen, onUpdateProject }) {
  const [isPhotoUploadModalOpen, setIsPhotoUploadModalOpen] = useState(false);
  const [selectedMilestoneForUpload, setSelectedMilestoneForUpload] = useState(null);
  const [isProgressUpdateModalOpen, setIsProgressUpdateModalOpen] = useState(false);
  const [selectedMilestoneForProgress, setSelectedMilestoneForProgress] = useState(null);

  const { toast } = useToast();

  // Memoize milestones status processing and total paid calculation
  const milestonesStatus = useMemo(() => {
    const status = project?.milestones ? { ...project.milestones } : initializeMilestonesStatus();
    // Ensure structure integrity
    projectMilestonesData.forEach(m => {
        if (!status[m.name]) status[m.name] = { paid: 0, images: [] };
        if (!Array.isArray(status[m.name].images)) status[m.name].images = [];
        if (typeof status[m.name].paid === 'undefined') status[m.name].paid = 0;
    });
    return status;
  }, [project?.milestones]);

  const totalPaid = useMemo(() => calculateTotalPaid(milestonesStatus), [milestonesStatus]);

  if (!project) return null;


  const handleMilestonePhotoClick = (milestoneName) => {
    setSelectedMilestoneForUpload(milestoneName);
    setIsPhotoUploadModalOpen(true);
  };

  const handleMilestoneProgressClick = (milestoneName) => {
    setSelectedMilestoneForProgress(milestoneName);
    setIsProgressUpdateModalOpen(true);
  };

  const handleAddImage = (milestoneName, imageUrl) => {
     const currentImages = milestonesStatus[milestoneName]?.images || [];
     const updatedMilestones = {
        ...milestonesStatus,
        [milestoneName]: {
            ...(milestonesStatus[milestoneName] || { paid: 0 }),
            images: [...currentImages, imageUrl]
        }
     };

     if (onUpdateProject) {
        onUpdateProject(project.id, { milestones: updatedMilestones });
     }

     toast({ title: "Foto Añadida (Simulado)", description: `Se añadió una foto a ${milestoneName}.`, variant: "success" });
  };

  const handleSaveMilestoneProgress = (milestoneName, newOverallProgress) => {
     if (onUpdateProject) {
        onUpdateProject(project.id, { progress: newOverallProgress });
        toast({ title: "Progreso Actualizado", description: `Progreso general: ${newOverallProgress}%.`, variant: "success" });
     } else {
         toast({ title: "Error", description: "No se pudo guardar el progreso.", variant: "destructive" });
     }
  };


  return (
    <>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        {/* Adjusted width and removed default padding */}
        <DialogContent className="sm:max-w-md p-0 overflow-hidden">
          {/* Header Section (similar to image) */}
          <div className="p-4 sm:p-6 border-b bg-gray-50">
            <DialogTitle className="text-xl font-semibold text-primary text-center mb-1">{project.modelName || project.name}</DialogTitle>
            <DialogDescription className="text-center text-sm text-gray-500">
                Detalles del proyecto para {project.client}
            </DialogDescription>
          </div>

          {/* Main Content Area */}
          <div className="p-4 sm:p-6 space-y-4 max-h-[70vh] overflow-y-auto">

             {/* Client and Address Info */}
             <div className="space-y-1.5 text-sm">
                <div className="flex items-center text-gray-700">
                   <User className="w-4 h-4 mr-2 text-primary flex-shrink-0" />
                   <span>Cliente: {project.client}</span>
                </div>
                <div className="flex items-center text-gray-700">
                   <Home className="w-4 h-4 mr-2 text-primary flex-shrink-0" />
                   <span>Dirección: {project.address}</span>
                </div>
             </div>

             {/* Financial Info */}
             <div className="flex items-center justify-between text-sm p-3 bg-blue-50 rounded-lg border border-blue-100">
                <div className="flex items-center font-medium text-gray-700">
                   <Wallet className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                   Total Recaudado:
                </div>
                <span className="font-bold text-blue-700">
                    ${totalPaid.toLocaleString('es-CL')}
                </span>
             </div>


            {/* Overall Progress */}
            <div className="space-y-1">
                <div className="flex justify-between items-center text-sm font-medium">
                  <span className="text-gray-700">Progreso General:</span>
                  <span className="font-bold text-primary">{project.progress}%</span>
                </div>
              <Progress value={project.progress} className="h-2 rounded-full" />
            </div>


            {/* Milestone List */}
            <div className="pt-2">
               <h4 className="text-sm font-semibold text-gray-800 mb-3">Avance por Hito:</h4>
               <MilestoneListDisplay
                  overallProgress={project.progress}
                  milestonesStatus={milestonesStatus}
                  showPaymentFeatures={false} // Constructor doesn't see payment buttons
                  onMilestonePhotoClick={handleMilestonePhotoClick}
                  onMilestoneProgressClick={handleMilestoneProgressClick}
                  userType="constructor"
                  className="mt-0" // Remove default margin if any
               />
            </div>

             <p className="text-xs text-center text-gray-500 pt-1">
                Haz clic en <span className='inline-flex items-center mx-0.5'><ImageIcon className='w-3 h-3 text-gray-500'/></span> o <span className='inline-flex items-center mx-0.5'><Edit2 className='w-3 h-3 text-gray-500'/></span> para actualizar.
             </p>

          </div>
           {/* Footer stays at the bottom */}
          <DialogFooter className="p-4 border-t bg-gray-50 sticky bottom-0">
            <Button variant="outline" onClick={() => setIsOpen(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Child Modals */}
      {selectedMilestoneForUpload && (
        <MilestonePhotoUploadDialog
          isOpen={isPhotoUploadModalOpen}
          setIsOpen={setIsPhotoUploadModalOpen}
          milestoneName={selectedMilestoneForUpload}
          existingImages={milestonesStatus[selectedMilestoneForUpload]?.images || []}
          onAddImage={handleAddImage}
        />
      )}

       {selectedMilestoneForProgress && (
         <MilestoneProgressUpdateDialog
           isOpen={isProgressUpdateModalOpen}
           setIsOpen={setIsProgressUpdateModalOpen}
           milestoneName={selectedMilestoneForProgress}
           overallProgress={project.progress}
           onSaveProgress={handleSaveMilestoneProgress}
         />
       )}
    </>
  );
}

export default ConstructorProjectDetailsDialog;
  