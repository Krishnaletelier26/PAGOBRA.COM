
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Star, User } from 'lucide-react';

// Helper function to render stars (non-interactive version)
const renderStars = (rating) => {
  return (
    <div className="flex text-yellow-400">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className="w-5 h-5"
          fill={i < rating ? 'currentColor' : 'none'}
        />
      ))}
    </div>
  );
};

function ClientReviewDialog({ project, isOpen, setIsOpen }) {
  // Use default empty review if none exists in data
  const review = project?.review || { rating: 0, text: 'Aún no hay reseña para este proyecto.' };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-primary">Reseña del Cliente</DialogTitle>
          <DialogDescription>
            Comentarios de {project?.client} sobre el proyecto "{project?.name}".
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-4">
          {/* Client Info */}
          <div className="flex items-center text-sm">
            <User className="w-4 h-4 mr-2 text-gray-500 flex-shrink-0" />
            <span>Cliente: <span className="font-medium text-gray-700">{project?.client || 'Desconocido'}</span></span>
          </div>

          {/* Rating */}
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-gray-700">Calificación:</span>
            {renderStars(review.rating)}
             <span className="text-sm text-gray-500">({review.rating}/5)</span>
          </div>

          {/* Review Text */}
          <div>
            <p className="text-sm font-medium text-gray-700 mb-1">Comentario:</p>
            <div className="p-3 border rounded bg-gray-50 min-h-[80px]">
              <p className="text-sm text-gray-600 italic">"{review.text}"</p>
            </div>
          </div>
        </div>
        <DialogFooter className="mt-4">
          <DialogClose asChild>
            <Button variant="outline">Cerrar</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default ClientReviewDialog;
  