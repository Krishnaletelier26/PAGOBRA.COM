
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { projectMilestonesData } from '@/lib/projectUtils';
import { useToast } from '@/components/ui/use-toast';

function MilestoneProgressUpdateDialog({
  isOpen,
  setIsOpen,
  milestoneName,
  overallProgress,
  onSaveProgress // Expects function(milestoneName, newOverallProgress)
}) {
  const [milestonePercentage, setMilestonePercentage] = useState([0]);
  const { toast } = useToast();

  const milestoneData = projectMilestonesData.find(m => m.name === milestoneName);

  // Initialize slider based on current overall progress relative to the milestone
  useEffect(() => {
    if (isOpen && milestoneData) {
      const [start, end] = milestoneData.range;
      let currentMilestoneProg = 0;
      if (overallProgress >= end) {
        currentMilestoneProg = 100;
      } else if (overallProgress > start) {
        currentMilestoneProg = Math.round(((overallProgress - start) / (end - start)) * 100);
      }
      setMilestonePercentage([currentMilestoneProg]);
    }
  }, [isOpen, milestoneName, overallProgress, milestoneData]);

  const handleSave = () => {
    if (!milestoneData) {
      toast({ title: "Error", description: "No se encontraron datos para este hito.", variant: "destructive" });
      return;
    }

    const [start, end] = milestoneData.range;
    const milestoneSpecificProgress = milestonePercentage[0] / 100; // Value from 0 to 1

    // Calculate the new overall progress based on this milestone's contribution
    const newOverallProgress = start + (end - start) * milestoneSpecificProgress;

    // Ensure progress doesn't exceed 100 or go below 0 (though slider prevents < 0)
    const clampedProgress = Math.min(100, Math.max(start, newOverallProgress)); // Clamp between milestone start and 100

    onSaveProgress(milestoneName, Math.round(clampedProgress)); // Pass rounded overall progress
    setIsOpen(false);
  };

  if (!milestoneData) return null; // Should not happen if opened correctly

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Actualizar Progreso: {milestoneName}</DialogTitle>
          <DialogDescription>
            Define el porcentaje completado para este hito específico. Esto actualizará el progreso general del proyecto.
          </DialogDescription>
        </DialogHeader>
        <div className="py-6 space-y-4">
           <Label htmlFor="milestone-progress-slider" className="text-center block">
             Progreso del Hito: <span className="font-bold text-primary">{milestonePercentage[0]}%</span>
           </Label>
           <Slider
             id="milestone-progress-slider"
             min={0}
             max={100}
             step={1}
             value={milestonePercentage}
             onValueChange={setMilestonePercentage}
             className="w-[90%] mx-auto"
           />
           <p className="text-xs text-center text-gray-500">
             Progreso general estimado: {Math.round(milestoneData.range[0] + (milestoneData.range[1] - milestoneData.range[0]) * (milestonePercentage[0] / 100))}%
           </p>
        </div>
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave}>
            Guardar Progreso
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default MilestoneProgressUpdateDialog;
  