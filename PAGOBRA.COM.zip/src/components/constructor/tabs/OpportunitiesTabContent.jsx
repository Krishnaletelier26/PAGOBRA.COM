
import React from 'react';
import OpportunityCard from '@/components/constructor/cards/OpportunityCard';
import { motion } from 'framer-motion';

function OpportunitiesTabContent({ opportunities, onApplyToProject }) {
  if (!opportunities || opportunities.length === 0) {
    return <p className="text-center text-gray-500 mt-8">No hay nuevas oportunidades de proyecto.</p>;
  }

  return (
    <div className="space-y-3">
      {opportunities.map((opportunity, index) => (
        <motion.div
          key={opportunity.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.05 }}
        >
          <OpportunityCard
            opportunity={opportunity}
            onApply={() => onApplyToProject(opportunity.id)}
          />
        </motion.div>
      ))}
    </div>
  );
}

export default OpportunitiesTabContent;
  