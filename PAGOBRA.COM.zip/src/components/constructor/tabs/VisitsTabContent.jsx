
import React from 'react';
import VisitRequestCard from '@/components/constructor/cards/VisitRequestCard';
import { motion } from 'framer-motion';

function VisitsTabContent({ visitRequests, onOpenProposalModal }) {
  if (!visitRequests || visitRequests.length === 0) {
    return <p className="text-center text-gray-500 mt-8">No hay solicitudes de visita pendientes.</p>;
  }

  return (
    <div className="space-y-3">
      {visitRequests.map((request, index) => (
         <motion.div
           key={request.id}
           initial={{ opacity: 0, y: 10 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.3, delay: index * 0.05 }}
         >
          <VisitRequestCard
            request={request}
            onOpenProposalModal={onOpenProposalModal}
          />
         </motion.div>
      ))}
    </div>
  );
}

export default VisitsTabContent;
  