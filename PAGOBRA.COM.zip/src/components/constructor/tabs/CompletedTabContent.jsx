
import React from 'react';
import CompletedProjectCard from '@/components/constructor/cards/CompletedProjectCard';
import { motion } from 'framer-motion';

function CompletedTabContent({ projects, onViewReview }) {
  if (!projects || projects.length === 0) {
    return <p className="text-center text-gray-500 mt-8">Aún no hay proyectos completados.</p>;
  }

  return (
    <div className="space-y-3">
      {projects.map((project, index) => (
         <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <CompletedProjectCard
              project={project}
              onViewReview={onViewReview}
            />
         </motion.div>
      ))}
    </div>
  );
}

export default CompletedTabContent;
  