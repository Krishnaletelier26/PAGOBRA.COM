
import React, { useState, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { FileText, User, Home as HomeIcon, Calendar, Clock } from 'lucide-react'; // Renamed Home to HomeIcon

function ProposalCreationDialog({ isOpen, setIsOpen, request, availableAdditionals, onSubmit }) {
  const [selectedAdditionals, setSelectedAdditionals] = useState({}); // Store checked state by id

  // Initialize selectedAdditionals when the dialog opens or request changes
  useEffect(() => {
    if (isOpen && request) {
      setSelectedAdditionals({});
    }
  }, [isOpen, request]);

  // Calculate total price
  const totalPrice = useMemo(() => {
    if (!request) return 0;
    const base = request.houseModel.basePrice || 0;
    const additionalTotal = availableAdditionals.reduce((sum, service) => {
      return selectedAdditionals[service.id] ? sum + (Number(service.price) || 0) : sum;
    }, 0);
    return base + additionalTotal;
  }, [request, availableAdditionals, selectedAdditionals]);

  const handleCheckboxChange = (serviceId) => {
    setSelectedAdditionals(prev => ({
      ...prev,
      [serviceId]: !prev[serviceId],
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!request) return;

    const proposalData = {
      basePrice: request.houseModel.basePrice,
      additionals: availableAdditionals
        .filter(service => selectedAdditionals[service.id])
        .map(({ id, name, price }) => ({ id, name, price })),
      totalPrice: totalPrice,
    };
    onSubmit(request.id, proposalData);
  };

  if (!request) return null;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center">
             <FileText className="w-5 h-5 mr-2 text-primary" /> Crear Propuesta para {request.ownerName}
          </DialogTitle>
          <DialogDescription>
            Revisa los detalles y agrega servicios adicionales si es necesario.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="py-4 space-y-4">
            {/* Request Details */}
            <div className="space-y-1 border p-3 rounded-md bg-secondary/50">
               <h4 className="text-sm font-semibold text-secondary-foreground mb-1">Detalles de la Solicitud</h4>
               <div className="flex items-center text-xs text-muted-foreground">
                 <User className="w-3 h-3 mr-1.5 flex-shrink-0" />
                 <span>{request.ownerName}</span>
               </div>
               <div className="flex items-center text-xs text-muted-foreground">
                 <HomeIcon className="w-3 h-3 mr-1.5 flex-shrink-0" />
                 <span>{request.ownerAddress}</span>
               </div>
               <div className="flex items-center text-xs text-muted-foreground">
                 <Calendar className="w-3 h-3 mr-1.5 flex-shrink-0" />
                 <span>Visita: {new Date(request.requestedDate + 'T00:00:00').toLocaleDateString('es-CL')}</span>
                 <Clock className="w-3 h-3 ml-2 mr-1.5 flex-shrink-0" />
                 <span>{request.requestedTime}</span>
               </div>
                <div className="flex items-center text-xs text-muted-foreground">
                 <HomeIcon className="w-3 h-3 mr-1.5 flex-shrink-0" />
                 <span>Modelo: {request.houseModel.name}</span>
               </div>
            </div>

            {/* Base Price */}
            <div>
              <Label className="text-sm font-medium text-gray-500">Precio base modelo:</Label>
              <p className="text-xl font-bold text-primary">${(request.houseModel.basePrice || 0).toLocaleString('es-CL')}</p>
            </div>

            <hr className="my-2 border-gray-200"/>

            {/* Additional Services */}
            <div>
              <Label className="text-md font-semibold text-gray-700 mb-2 block">Servicios Adicionales Disponibles:</Label>
              <ScrollArea className="h-[200px] w-full rounded-md border p-3">
                 <div className="space-y-2">
                    {availableAdditionals.map((service) => (
                        <div key={service.id} className="flex items-center justify-between pr-1">
                            <div className="flex items-center space-x-2">
                                <Checkbox
                                    id={`add-${service.id}`}
                                    checked={!!selectedAdditionals[service.id]}
                                    onCheckedChange={() => handleCheckboxChange(service.id)}
                                />
                                <Label htmlFor={`add-${service.id}`} className="text-sm font-medium text-gray-600 cursor-pointer">
                                    {service.name}
                                </Label>
                            </div>
                            <span className="text-sm text-gray-700 font-medium">${(Number(service.price) || 0).toLocaleString('es-CL')}</span>
                        </div>
                    ))}
                 </div>
              </ScrollArea>
            </div>
          </div>

          <DialogFooter className="mt-4 pt-4 border-t flex items-center justify-between">
             <div>
                <Label className="text-sm font-medium text-gray-500">Propuesta total:</Label>
                <p className="text-xl font-bold text-primary">${totalPrice.toLocaleString('es-CL')}</p>
             </div>
            <Button type="submit">
              Enviar Propuesta
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default ProposalCreationDialog;
  