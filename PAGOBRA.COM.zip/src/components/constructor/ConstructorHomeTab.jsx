
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, FolderOpen, FolderCheck } from 'lucide-react';
import { motion } from 'framer-motion';
import useConstructorData from '@/hooks/useConstructorData';
import ProposalCreationDialog from '@/components/constructor/ProposalCreationDialog';
import ConstructorProjectDetailsDialog from '@/components/constructor/ConstructorProjectDetailsDialog';
import ClientReviewDialog from '@/components/constructor/ClientReviewDialog';
import VisitRequestCard from '@/components/constructor/cards/VisitRequestCard';
import InProgressProjectCard from '@/components/constructor/cards/InProgressProjectCard';
import CompletedProjectCard from '@/components/constructor/cards/CompletedProjectCard';

function ConstructorHomeTab() {
  const {
    visitRequests,
    inProgressProjects,
    completedProjects,
    availableAdditionals,
    selectedRequest,
    isProposalModalOpen,
    handleOpenProposalModal,
    handleSendProposal,
    setIsProposalModalOpen,
    setSelectedRequest,
    updateProjectData,
    getProjectReview,
  } = useConstructorData();

  const [selectedProjectForDetails, setSelectedProjectForDetails] = useState(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [selectedProjectForReview, setSelectedProjectForReview] = useState(null);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);

  const handleViewDetails = (project) => {
    setSelectedProjectForDetails(project);
    setIsDetailsModalOpen(true);
  };

  const handleViewReview = (project) => {
    const reviewData = getProjectReview(project.id);
    setSelectedProjectForReview({ ...project, review: reviewData });
    setIsReviewModalOpen(true);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-0 sm:p-0">
      {/* Adjusted Header */}
      <div className="p-4 sm:p-6">
        <h1 className="text-2xl sm:text-3xl font-bold text-primary mb-1">Panel de Constructora</h1>
        <p className="text-sm text-blue-700">Gestiona tus visitas, proyectos en curso y completados.</p>
      </div>

      <Tabs defaultValue="visitas" className="w-full px-4 sm:px-6 pb-4 sm:pb-6"> {/* Added padding here */}
        {/* Adjusted TabsList styling via ui/tabs.jsx */}
        <TabsList className="grid w-full grid-cols-3 gap-0 mb-4"> {/* Removed gap, bg */}
          <TabsTrigger value="visitas" className="py-2 text-sm font-medium">
            <FileText className="w-4 h-4 mr-1.5 sm:mr-2"/> Visitas ({visitRequests.length})
          </TabsTrigger>
          <TabsTrigger value="en-obra" className="py-2 text-sm font-medium">
             <FolderOpen className="w-4 h-4 mr-1.5 sm:mr-2"/> En Obra ({inProgressProjects.length})
          </TabsTrigger>
          <TabsTrigger value="completados" className="py-2 text-sm font-medium">
             <FolderCheck className="w-4 h-4 mr-1.5 sm:mr-2"/> Completados ({completedProjects.length})
          </TabsTrigger>
        </TabsList>

        {/* Visitas Tab Content */}
        <TabsContent value="visitas">
          {visitRequests.length > 0 ? (
            <div className="space-y-3">
              {visitRequests.map((request) => (
                <VisitRequestCard
                  key={request.id}
                  request={request}
                  onOpenProposalModal={handleOpenProposalModal}
                />
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500 mt-8">No hay solicitudes de visita pendientes.</p>
          )}
        </TabsContent>

        {/* En Obra Tab Content */}
        <TabsContent value="en-obra">
           {inProgressProjects.length > 0 ? (
             <div className="space-y-3">
                {inProgressProjects.map((project) => (
                  <InProgressProjectCard
                    key={project.id}
                    project={project}
                    onViewDetails={handleViewDetails}
                  />
                ))}
             </div>
           ) : (
             <p className="text-center text-gray-500 mt-8">No hay proyectos en obra actualmente.</p>
           )}
        </TabsContent>

        {/* Completados Tab Content */}
        <TabsContent value="completados">
          {completedProjects.length > 0 ? (
             <div className="space-y-3">
                {completedProjects.map((project) => (
                  <CompletedProjectCard
                    key={project.id}
                    project={project}
                    onViewReview={handleViewReview}
                  />
                ))}
             </div>
           ) : (
             <p className="text-center text-gray-500 mt-8">Aún no hay proyectos completados.</p>
           )}
        </TabsContent>
      </Tabs>

      {/* Modals */}
      {selectedRequest && (
        <ProposalCreationDialog
          isOpen={isProposalModalOpen}
          setIsOpen={(open) => {
            setIsProposalModalOpen(open);
            if (!open) setSelectedRequest(null);
          }}
          request={selectedRequest}
          availableAdditionals={availableAdditionals}
          onSubmit={handleSendProposal}
        />
      )}

      {selectedProjectForDetails && (
        <ConstructorProjectDetailsDialog
          project={selectedProjectForDetails}
          isOpen={isDetailsModalOpen}
          setIsOpen={setIsDetailsModalOpen}
          onUpdateProject={updateProjectData}
        />
      )}

      {selectedProjectForReview && (
        <ClientReviewDialog
          project={selectedProjectForReview}
          isOpen={isReviewModalOpen}
          setIsOpen={(open) => {
             setIsReviewModalOpen(open);
             if (!open) setSelectedProjectForReview(null);
           }}
        />
      )}
    </motion.div>
  );
}

export default ConstructorHomeTab;
  