
import React from 'react';
import { Button } from '@/components/ui/button';
import { CheckCircle, AlertCircle } from 'lucide-react';

function PaymentActionArea({ nextPayableMilestone, selectedMilestoneToPay, onOpenPaymentModal, projectProgress }) {
    return (
        <div className="mt-4 pt-4 border-t">
            {nextPayableMilestone ? (
                <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
                    <p className="text-sm text-gray-600 text-center sm:text-left">
                        Próximo pago requerido: <span className="font-semibold text-primary">{nextPayableMilestone.name}</span> (${nextPayableMilestone.cost.toLocaleString('es-CL')})
                    </p>
                    <Button
                        onClick={onOpenPaymentModal}
                        disabled={!selectedMilestoneToPay || selectedMilestoneToPay.name !== nextPayableMilestone.name}
                        className="w-full sm:w-auto"
                    >
                        Proceder al Pago
                    </Button>
                </div>
            ) : projectProgress >= 100 ? (
                <div className="flex items-center justify-center text-sm text-green-600">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    <span>¡Proyecto completado!</span>
                </div>
            ) : (
                <div className="flex items-center justify-center text-sm text-orange-600">
                    <AlertCircle className="w-4 h-4 mr-2" />
                    <span>Esperando avance para el próximo pago.</span>
                </div>
            )}
        </div>
    );
}

export default PaymentActionArea;
  