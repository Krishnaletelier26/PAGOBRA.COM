
import React from 'react';
import { Calendar, Flag, User, Home } from 'lucide-react';

const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return new Date(dateString).toLocaleDateString('es-CL', { year: 'numeric', month: 'short', day: 'numeric' });
    } catch (e) {
      console.error("Error formatting date:", dateString, e);
      return 'Fecha Inválida';
    }
};

function ProjectInfoDisplay({ project }) {
    if (!project) return null;

    const { client, address, builderName, details } = project;

    return (
        <div className="space-y-2">
            {builderName && ( // Show builder if available (for owner view)
                <div className="flex items-center text-sm">
                    <User className="w-4 h-4 mr-2 text-gray-500 flex-shrink-0" />
                    <span>Constructor: <span className="font-medium text-gray-700">{builderName}</span></span>
                </div>
            )}
             {client && ( // Show client if available (for constructor view)
                <div className="flex items-center text-sm">
                    <User className="w-4 h-4 mr-2 text-gray-500 flex-shrink-0" />
                    <span>Cliente: <span className="font-medium text-gray-700">{client}</span></span>
                </div>
            )}
            {address && (
                <div className="flex items-center text-sm">
                    <Home className="w-4 h-4 mr-2 text-gray-500 flex-shrink-0" />
                    <span>Dirección: <span className="font-medium text-gray-700">{address}</span></span>
                </div>
            )}
            {details && (
                <>
                    <div className="flex items-center text-sm">
                        <Calendar className="w-4 h-4 mr-2 text-gray-500 flex-shrink-0" />
                        <span>Inicio: <span className="font-medium text-gray-700">{formatDate(details.startDate)}</span></span>
                    </div>
                    <div className="flex items-center text-sm">
                        <Calendar className="w-4 h-4 mr-2 text-gray-500 flex-shrink-0" />
                        <span>Fin Estimado: <span className="font-medium text-gray-700">{formatDate(details.estimatedEndDate)}</span></span>
                    </div>
                    <div className="flex items-center text-sm">
                        <Flag className="w-4 h-4 mr-2 text-gray-500 flex-shrink-0" />
                        <span>Fase Actual: <span className="font-medium text-gray-700">{details.currentPhase || 'N/A'}</span></span>
                    </div>
                </>
            )}
        </div>
    );
}

export default ProjectInfoDisplay;
  