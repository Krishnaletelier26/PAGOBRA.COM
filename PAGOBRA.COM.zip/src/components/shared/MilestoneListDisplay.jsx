
import React from 'react';
import MilestoneItem from '@/components/home/MilestoneItem';
import { projectMilestonesData, findNextActionableMilestone } from '@/lib/projectUtils';
import { cn } from '@/lib/utils';

function MilestoneListDisplay({
  overallProgress,
  milestonesStatus = {},
  showPaymentFeatures = false,
  // Removed selectedMilestoneName, onCheckboxChange
  onMilestonePhotoClick = null,
  onMilestoneProgressClick = null,
  onPayButtonClick = null, // Added handler for pay button click
  userType = 'owner',
  className,
  isDetailPopoverOpen,
  selectedMilestoneForDetail,
  onOpenDetailPopover,
  onCloseDetailPopover,
}) {
  const nextPayableMilestone = showPaymentFeatures
    ? findNextActionableMilestone(overallProgress, milestonesStatus)
    : null;

  return (
    <div className={cn("relative space-y-0", className)}>
      {/* Vertical line */}
      <div className="absolute left-4 sm:left-5 top-2 bottom-2 w-0.5 bg-gray-200" />

      {projectMilestonesData.map((milestone, index) => {
        const isPayableNow = showPaymentFeatures && nextPayableMilestone?.name === milestone.name;
        // Check if previous milestone is complete before allowing payment interaction
        const previousMilestoneIndex = index - 1;
        let isPreviousComplete = true;
        if (previousMilestoneIndex >= 0) {
            const prevMilestone = projectMilestonesData[previousMilestoneIndex];
            isPreviousComplete = overallProgress >= prevMilestone.range[1];
        }

        // Payment button is only active if it's payable now AND previous is complete
        const canPayNow = isPayableNow && isPreviousComplete;

        const currentMilestoneStatus = milestonesStatus[milestone.name] || { paid: 0, images: [] };
        const isPhotoClickable = !!onMilestonePhotoClick;
        const isProgressClickable = userType === 'constructor' && !!onMilestoneProgressClick;
        const isCurrentDetailPopoverOpen = isDetailPopoverOpen && selectedMilestoneForDetail === milestone.name;

        return (
          <MilestoneItem
            key={milestone.name}
            milestone={milestone}
            overallProgress={overallProgress}
            milestoneDetails={currentMilestoneStatus}
            isPayableNow={canPayNow} // Pass the calculated payability
            // Removed isSelected, onCheckboxChange, isCheckboxInteractive
            showPaymentFeatures={showPaymentFeatures}
            onPhotoClick={isPhotoClickable ? () => onMilestonePhotoClick(milestone.name, currentMilestoneStatus.images || []) : undefined}
            onProgressClick={isProgressClickable ? () => onMilestoneProgressClick(milestone.name) : undefined}
            onPayClick={canPayNow && onPayButtonClick ? onPayButtonClick : undefined} // Pass pay click handler only if active
            isPhotoClickable={isPhotoClickable}
            isProgressClickable={isProgressClickable}
            userType={userType}
            isLast={index === projectMilestonesData.length - 1}
            isDetailPopoverOpen={isCurrentDetailPopoverOpen}
            onOpenDetailPopover={onOpenDetailPopover}
            onCloseDetailPopover={onCloseDetailPopover}
          />
        );
      })}
    </div>
  );
}

export default MilestoneListDisplay;
  