
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from "@/components/ui/use-toast";

// Mock data for a new client request
const mockClientRequest = {
  id: 'req001',
  modelName: 'Modelo Austral',
  clientName: 'Carlos Silva',
  address: 'Camino El Oliveto 450, Talagante',
  basePrice: 8200000,
  additionalServices: [
    { id: 'svc1', name: 'Fosa séptica', price: 550000, checked: true },
    { id: 'svc2', name: 'Caseta Calefont', price: 180000, checked: false },
    { id: 'svc3', name: 'Baño químico (arriendo mensual)', price: 120000, checked: true },
    { id: 'svc4', name: 'Aislante térmico adicional', price: 350000, checked: false },
    { id: 'svc5', name: 'Generador eléctrico (arriendo diario)', price: 90000, checked: false },
  ],
  clientDetails: {
    agua: 'Sí',
    luz: 'Sí',
    terreno: 'Nivel pendiente, requiere nivelación',
  },
};

function BuilderHomeTab() {
  const [request, setRequest] = useState(mockClientRequest);
  const { toast } = useToast();

  const handleServiceCheckChange = (serviceId, isChecked) => {
    setRequest(prevRequest => ({
      ...prevRequest,
      additionalServices: prevRequest.additionalServices.map(service =>
        service.id === serviceId ? { ...service, checked: isChecked } : service
      ),
    }));
  };

  const calculateTotal = () => {
    const additionalCost = request.additionalServices
      .filter(service => service.checked)
      .reduce((sum, service) => sum + service.price, 0);
    return request.basePrice + additionalCost;
  };

  const handleSendProposal = () => {
    const total = calculateTotal();
    console.log("Enviando propuesta:", { requestId: request.id, total, services: request.additionalServices.filter(s => s.checked) });
    toast({
      title: "Propuesta Enviada",
      description: `Propuesta por $${total.toLocaleString('es-CL')} enviada a ${request.clientName}.`,
    });
    // Here you would typically trigger an API call and update state accordingly
    // For simulation, maybe disable the button or show a confirmation state
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Nuevas Solicitudes de Clientes</h2>

      <Card className="shadow-lg border border-gray-200 bg-white">
        <CardHeader className="bg-gray-50/50">
          <CardTitle className="text-lg text-primary">{request.modelName}</CardTitle>
          <CardDescription>
            Solicitud de: {request.clientName} - {request.address}
          </CardDescription>
        </CardHeader>
        <CardContent className="p-4 space-y-4">
          <div>
            <Label className="text-sm font-medium text-gray-600">Precio base estimado:</Label>
            <p className="text-xl font-bold text-gray-800">
              ${request.basePrice.toLocaleString('es-CL')}
            </p>
          </div>

          <div className="border-t pt-4">
            <Label className="text-sm font-medium text-gray-600 mb-2 block">Agregar Servicios Adicionales:</Label>
            <div className="space-y-2">
              {request.additionalServices.map((service) => (
                <div key={service.id} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id={service.id}
                      checked={service.checked}
                      onCheckedChange={(checked) => handleServiceCheckChange(service.id, checked)}
                    />
                    <Label htmlFor={service.id} className="text-sm font-normal cursor-pointer">
                      {service.name}
                    </Label>
                  </div>
                  <span className="text-sm text-gray-700">
                    ${service.price.toLocaleString('es-CL')}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t pt-4">
            <Label className="text-sm font-medium text-gray-600 mb-1 block">Detalles del cliente:</Label>
            <p className="text-sm text-gray-700">Agua: {request.clientDetails.agua}</p>
            <p className="text-sm text-gray-700">Luz: {request.clientDetails.luz}</p>
            <p className="text-sm text-gray-700">Terreno: {request.clientDetails.terreno}</p>
          </div>

          <div className="border-t pt-4 flex items-center justify-between">
            <div>
              <Label className="text-sm font-medium text-gray-600">Propuesta total:</Label>
              <p className="text-xl font-bold text-primary">
                ${calculateTotal().toLocaleString('es-CL')}
              </p>
            </div>
            <Button onClick={handleSendProposal} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" /> Enviar propuesta
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default BuilderHomeTab;
  