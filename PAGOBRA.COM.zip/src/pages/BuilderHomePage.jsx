
import React, { useState } from 'react';
import { Home, ListChecks, MessageSquare } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'; // Reusing Tabs component
import TopNav from '@/components/home/TopNav'; // Reusing TopNav, will adapt title
import BuilderHomeTab from '@/components/builder/BuilderHomeTab'; // New Builder Home Tab
// Placeholder for future Builder Projects and Chat tabs
// import BuilderProjectsTab from '@/components/builder/BuilderProjectsTab';
// import BuilderChatTab from '@/components/builder/BuilderChatTab';
import { motion } from 'framer-motion';

function BuilderHomePage() {
  const [activeTab, setActiveTab] = useState('inicio');
  // Placeholder states for other tabs if needed later
  // const [projectSearch, setProjectSearch] = useState('');
  // const [chatSearch, setChatSearch] = useState('');

  return (
    <div className="flex flex-col h-screen">
      {/* Pass userType or specific title */}
      <TopNav title="Panel de Constructora" userType="builder" />

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="flex-grow overflow-y-auto pb-16 sm:pb-4 pt-16" // Adjust padding top to account for sticky TopNav/Tabs
      >
         <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full h-full flex flex-col">
             {/* Builder specific Tabs List - potentially sticky */}
             <div className="sticky top-16 z-10 bg-white/95 backdrop-blur-sm px-4 sm:px-6 py-2 border-b">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="inicio" className="data-[state=active]:bg-blue-100 data-[state=active]:text-primary">
                        <Home className="w-4 h-4 mr-1 sm:mr-2"/> Inicio
                    </TabsTrigger>
                    <TabsTrigger value="proyectos" className="data-[state=active]:bg-blue-100 data-[state=active]:text-primary">
                        <ListChecks className="w-4 h-4 mr-1 sm:mr-2"/> Proyectos
                    </TabsTrigger>
                     <TabsTrigger value="charlar" className="data-[state=active]:bg-blue-100 data-[state=active]:text-primary">
                        <MessageSquare className="w-4 h-4 mr-1 sm:mr-2"/> Charlar
                    </TabsTrigger>
                </TabsList>
             </div>

            {/* Tab Content */}
            <div className="flex-grow p-4 sm:p-6">
                <TabsContent value="inicio" className="mt-0 h-full">
                    <BuilderHomeTab />
                </TabsContent>
                <TabsContent value="proyectos" className="mt-0 h-full">
                    {/* Placeholder for BuilderProjectsTab */}
                    <div className="text-center text-gray-500 py-10">Vista de Proyectos (Constructor) - Próximamente</div>
                </TabsContent>
                <TabsContent value="charlar" className="mt-0 h-full">
                    {/* Placeholder for BuilderChatTab */}
                    <div className="text-center text-gray-500 py-10">Vista de Chats (Constructor) - Próximamente</div>
                </TabsContent>
            </div>
         </Tabs>
      </motion.div>

      {/* No BottomNav for builder? Or a different one? For now, none. */}
       {/* <BuilderBottomNav activeTab={activeTab} setActiveTab={setActiveTab} /> */}
    </div>
  );
}

export default BuilderHomePage;
  