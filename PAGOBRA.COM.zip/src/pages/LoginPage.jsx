
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { motion } from 'framer-motion';
import { useToast } from "@/components/ui/use-toast"; // Import useToast

function LoginPage() {
  const navigate = useNavigate();
  const { toast } = useToast(); // Use toast hook
  const [activeTab, setActiveTab] = useState('propietario'); // Default to owner

  const handleLogin = () => {
    // Simulación de login exitoso
    console.log(`Iniciando sesión como: ${activeTab}`);

    // Guardar el tipo de usuario en localStorage
    try {
      localStorage.setItem('userType', activeTab);
      toast({
        title: "Inicio de Sesión Exitoso (Simulado)",
        description: `Bienvenido de vuelta.`,
      });
      navigate('/home'); // Navegar a la página principal
    } catch (error) {
      console.error("Error saving user type to localStorage:", error);
      toast({
        title: "Error de Inicio de Sesión",
        description: "No se pudo guardar la información del usuario.",
        variant: "destructive",
      });
    }
  };

  const handleRegisterRedirect = () => {
    navigate('/register');
  };

  return (
    <div className="flex items-center justify-center min-h-screen p-4 bg-gradient-to-br from-blue-100 via-white to-blue-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-sm"
      >
        <Card className="shadow-xl border-blue-200 border">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-primary">Iniciar Sesión</CardTitle>
            <CardDescription>Accede a tu cuenta de Pagobra</CardDescription>
          </CardHeader>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full px-6 pt-0 pb-6">
             <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="propietario" className="data-[state=active]:bg-blue-100 data-[state=active]:text-primary">
                Propietario
              </TabsTrigger>
              <TabsTrigger value="constructora" className="data-[state=active]:bg-blue-100 data-[state=active]:text-primary">
                Constructora
              </TabsTrigger>
            </TabsList>

            {/* Contenido Común para Email/Password */}
             <TabsContent value="propietario" forceMount> {/* forceMount para que el contenido exista aunque no esté activo */}
               <CardContent className="space-y-4 p-0">
                 <div className="space-y-2">
                   <Label htmlFor="owner-email">Correo Electrónico</Label>
                   <Input id="owner-email" type="email" placeholder="tu@correo.com" />
                 </div>
                 <div className="space-y-2">
                   <Label htmlFor="owner-password">Contraseña</Label>
                   <Input id="owner-password" type="password" placeholder="********" />
                 </div>
               </CardContent>
             </TabsContent>
            <TabsContent value="constructora" forceMount>
              <CardContent className="space-y-4 p-0">
                 <div className="space-y-2">
                   <Label htmlFor="builder-email">Correo Electrónico</Label>
                   <Input id="builder-email" type="email" placeholder="contacto@constructora.com" />
                 </div>
                 <div className="space-y-2">
                   <Label htmlFor="builder-password">Contraseña</Label>
                   <Input id="builder-password" type="password" placeholder="********" />
                 </div>
               </CardContent>
            </TabsContent>

           </Tabs>

          <CardFooter className="flex flex-col space-y-4 px-6 pb-6 pt-0">
            <Button onClick={handleLogin} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Iniciar Sesión
            </Button>
            <Button variant="link" onClick={handleRegisterRedirect} className="text-blue-600">
              ¿No tienes cuenta? Regístrate
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
}

export default LoginPage;
  