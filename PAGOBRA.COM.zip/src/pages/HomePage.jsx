
import React, { useState, useEffect } from 'react';
import BottomNav from '@/components/home/BottomNav';
import TopNav from '@/components/home/TopNav';
import ProfileDialog from '@/components/home/ProfileDialog';
import OwnerDashboard from '@/components/dashboards/OwnerDashboard';
import ConstructorDashboard from '@/components/dashboards/ConstructorDashboard';
import ProposalReviewDialog from '@/components/owner/ProposalReviewDialog';
import useUserSession from '@/hooks/useUserSession';
import { loadFromLocalStorage } from '@/lib/storageUtils'; // Import helper

// Extracted Dashboard Rendering Logic
const RenderDashboard = ({ userType, activeTab, setActiveTab, activeChatId, setActiveChatId }) => {
  if (!userType) {
    return <div className="flex items-center justify-center h-full">Cargando...</div>;
  }

  const dashboardProps = { activeTab, setActiveTab, activeChatId, setActiveChatId };

  switch (userType) {
    case 'propietario':
      return <OwnerDashboard {...dashboardProps} />;
    case 'constructora':
      return <ConstructorDashboard {...dashboardProps} />;
    default:
      return <div className="flex items-center justify-center h-full text-red-500">Error: Tipo de usuario inválido.</div>;
  }
};

// Extracted Notification Handling Logic (Conceptual - can be further refined)
const useNotificationHandler = (userType, handleProposalAction) => {
    const [isProposalReviewOpen, setIsProposalReviewOpen] = useState(false);
    const [currentProposal, setCurrentProposal] = useState(null);
    const [hasNotification, setHasNotification] = useState(false);
    const [notificationData, setNotificationData] = useState(null);

    // Effect to check for pending proposals for the owner
    useEffect(() => {
        if (userType === 'propietario') {
            const checkProposals = () => {
                const builders = loadFromLocalStorage('ownerBuildersData', []);
                const pendingProposalBuilder = builders.find(b => b.status === 'proposal_received' && b.proposalDetails);

                if (pendingProposalBuilder) {
                    const proposal = {
                        id: pendingProposalBuilder.proposalDetails.visitRequestId, // Use visitRequestId as unique ID for action
                        builderName: pendingProposalBuilder.name,
                        projectName: `Modelo ${pendingProposalBuilder.model}`, // Example project name
                        basePrice: pendingProposalBuilder.proposalDetails.basePrice,
                        additionals: pendingProposalBuilder.proposalDetails.selectedAdditionals || [],
                        totalPrice: pendingProposalBuilder.proposalDetails.totalPrice,
                        status: 'pending' // Mark as pending for review
                    };
                    setNotificationData(proposal);
                    setHasNotification(true);
                } else {
                    setNotificationData(null);
                    setHasNotification(false);
                }
            };

            const intervalId = setInterval(checkProposals, 5000); // Check every 5 seconds
            checkProposals(); // Initial check

            return () => clearInterval(intervalId);
        } else {
            // Reset for constructor
            setNotificationData(null);
            setHasNotification(false);
        }
    }, [userType]);


    const handleOpenProposalReview = () => {
        if (notificationData && notificationData.status === 'pending') {
            setCurrentProposal(notificationData);
            setIsProposalReviewOpen(true);
        } else {
            console.log("Notification clicked, but proposal not pending or no proposal data.");
        }
    };

    const handleProposalActionAndClose = (proposalId, accepted) => {
        handleProposalAction(proposalId, accepted); // Call the main hook's action handler
        setIsProposalReviewOpen(false);
        setCurrentProposal(null);
        setHasNotification(false); // Assume notification is handled
        setNotificationData(null);
    };

    return {
        isProposalReviewOpen,
        currentProposal,
        hasNotification,
        notificationData,
        handleOpenProposalReview,
        handleProposalActionAndClose,
        setIsProposalReviewOpen // Expose setter if needed externally
    };
};


function HomePage() {
  const { userType, handleProposalAction: handleHookProposalAction } = useUserSession(); // Renamed original handler

  const [activeTab, setActiveTab] = useState('inicio');
  const [activeChatId, setActiveChatId] = useState(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  // Use the extracted notification handler hook
  const {
      isProposalReviewOpen,
      currentProposal,
      hasNotification,
      notificationData,
      handleOpenProposalReview,
      handleProposalActionAndClose,
      setIsProposalReviewOpen // Get setter from hook
  } = useNotificationHandler(userType, handleHookProposalAction);


  const handleProfileClick = () => {
    setIsProfileOpen(true);
  };

  // Determine if the notification icon should trigger the proposal review
  const onNotificationClickAction = userType === 'propietario' && notificationData?.status === 'pending'
    ? handleOpenProposalReview
    : null;


  return (
    <div className="flex flex-col h-screen bg-gradient-to-b from-blue-50 to-white">
      <TopNav
        onProfileClick={handleProfileClick}
        userType={userType}
        hasNotification={hasNotification}
        // Pass notificationData for potential display in TopNav if needed
        // notificationData={notificationData}
        onNotificationClick={onNotificationClickAction} // Use the determined action
      />

      <div className="flex-grow flex flex-col overflow-hidden">
        <RenderDashboard
            userType={userType}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            activeChatId={activeChatId}
            setActiveChatId={setActiveChatId}
         />
      </div>

      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeChatId={activeChatId}
        setActiveChatId={setActiveChatId}
      />

      <ProfileDialog isOpen={isProfileOpen} setIsOpen={setIsProfileOpen} userType={userType} />

      {/* Proposal Review Dialog managed by the hook */}
      {userType === 'propietario' && currentProposal && (
         <ProposalReviewDialog
           isOpen={isProposalReviewOpen}
           setIsOpen={setIsProposalReviewOpen} // Pass setter from hook
           proposal={currentProposal}
           onAction={handleProposalActionAndClose} // Pass closer from hook
         />
      )}
    </div>
  );
}

export default HomePage;
  