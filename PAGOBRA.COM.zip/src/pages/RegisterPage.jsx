
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'; // Import Tabs components
import { motion } from 'framer-motion';
import { useToast } from "@/components/ui/use-toast"; // Import useToast

function RegisterPage() {
  const navigate = useNavigate();
  const { toast } = useToast(); // Use toast hook
  const [activeTab, setActiveTab] = useState('propietario'); // State for active tab

  const handleRegister = () => {
    // Simulación de registro exitoso
    console.log(`Registrando como: ${activeTab}`);

    // Guardar el tipo de usuario en localStorage
    try {
      localStorage.setItem('userType', activeTab);
      toast({
        title: "Registro Exitoso (Simulado)",
        description: `Has sido registrado como ${activeTab === 'propietario' ? 'Propietario' : 'Constructora'}.`,
      });
      navigate('/home'); // Navegar a la página principal
    } catch (error) {
      console.error("Error saving user type to localStorage:", error);
      toast({
        title: "Error de Registro",
        description: "No se pudo guardar la información del usuario.",
        variant: "destructive",
      });
    }
  };

  const handleLoginRedirect = () => {
    navigate('/login');
  };

  return (
    <div className="flex items-center justify-center min-h-screen p-4 bg-gradient-to-br from-blue-100 via-white to-blue-50">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md" // Increased max-width slightly
      >
        <Card className="shadow-xl border-blue-200 border">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-primary">Crear Cuenta</CardTitle>
             {/* CardDescription eliminada */}
          </CardHeader>

          {/* Added padding-top since description is removed */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full px-6 pt-6 pb-6">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="propietario" className="data-[state=active]:bg-blue-100 data-[state=active]:text-primary">
                Propietario {/* Texto cambiado */}
              </TabsTrigger>
              <TabsTrigger value="constructora" className="data-[state=active]:bg-blue-100 data-[state=active]:text-primary">
                Constructora {/* Texto cambiado */}
              </TabsTrigger>
            </TabsList>

            {/* Contenido Pestaña Propietario */}
            <TabsContent value="propietario">
              <CardContent className="space-y-4 p-0">
                <div className="space-y-2">
                  <Label htmlFor="owner-name">Nombre Completo</Label>
                  <Input id="owner-name" type="text" placeholder="Tu Nombre" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="owner-email">Correo Electrónico</Label>
                  <Input id="owner-email" type="email" placeholder="tu@correo.com" />
                </div>
                 <div className="space-y-2">
                  <Label htmlFor="owner-phone">Teléfono</Label> {/* Texto (Opcional) eliminado */}
                  <Input id="owner-phone" type="tel" placeholder="+56 9 1234 5678" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="owner-password">Contraseña</Label>
                  <Input id="owner-password" type="password" placeholder="********" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="owner-confirm-password">Confirmar Contraseña</Label>
                  <Input id="owner-confirm-password" type="password" placeholder="********" />
                </div>
              </CardContent>
            </TabsContent>

            {/* Contenido Pestaña Constructora */}
            <TabsContent value="constructora">
              <CardContent className="space-y-4 p-0">
                 <div className="space-y-2">
                  <Label htmlFor="builder-company-name">Nombre de la Empresa</Label>
                  <Input id="builder-company-name" type="text" placeholder="Constructora XYZ" />
                </div>
                 <div className="space-y-2">
                  <Label htmlFor="builder-contact-name">Nombre de Contacto</Label>
                  <Input id="builder-contact-name" type="text" placeholder="Nombre del Representante" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="builder-email">Correo Electrónico</Label>
                  <Input id="builder-email" type="email" placeholder="contacto@constructora.com" />
                </div>
                 <div className="space-y-2">
                  <Label htmlFor="builder-phone">Teléfono de Contacto</Label>
                  <Input id="builder-phone" type="tel" placeholder="+56 2 9876 5432" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="builder-password">Contraseña</Label>
                  <Input id="builder-password" type="password" placeholder="********" />
                </div>
                 <div className="space-y-2">
                  <Label htmlFor="builder-confirm-password">Confirmar Contraseña</Label>
                  <Input id="builder-confirm-password" type="password" placeholder="********" />
                </div>
              </CardContent>
            </TabsContent>
          </Tabs>

          {/* Footer común */}
          <CardFooter className="flex flex-col space-y-4 px-6 pb-6 pt-0">
            <Button onClick={handleRegister} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Registrarse como {activeTab === 'propietario' ? 'Propietario' : 'Constructora'}
            </Button>
            <Button variant="link" onClick={handleLoginRedirect} className="text-blue-600">
              ¿Ya tienes cuenta? Inicia Sesión
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
}

export default RegisterPage;
  